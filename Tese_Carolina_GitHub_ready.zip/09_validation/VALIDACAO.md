# Relatório de validação da entrega

## Execução integral

O pipeline `python run_all.py` foi executado com sucesso em 25 de outubro de 2026, em Python 3.13.5, com as versões fixadas em `requirements.txt`:

- NumPy 2.3.5
- pandas 2.2.3
- SciPy 1.17.0
- scikit-learn 1.8.0
- openpyxl 3.1.5
- Matplotlib 3.10.8

A instalação destas dependências a partir de um ambiente virtual novo não foi testada de forma independente.

## Verificações dos dados

- As 30 fontes SNS foram lidas e processadas.
- O painel mensal contém 540 observações: cinco regiões × 108 meses (janeiro de 2017 a dezembro de 2025).
- Não existem valores em falta nos seis indicadores operacionais reconstruídos.
- A diferença absoluta máxima entre os indicadores reconstruídos e os indicadores mensais de referência é `1.42e-14`.
- O painel analítico foi construído a partir de `02_data_intermediate/pressure_indicators_monthly.csv`.
- A diferença absoluta máxima entre o índice reconstruído e o índice de referência é `1.11e-15`; não existem diferenças nos estados ordinais.
- Os ficheiros de origem e de inputs preservados passaram a verificação SHA-256.

## Verificações do modelo

Os sete testes automáticos passaram. Verificam a cronologia das previsões, a dimensão e os eventos da amostra de 2025, as métricas ridge–DTMC, a matriz de classificação ao limiar 0.6, a integridade das entradas, a equivalência dos indicadores e a reconstrução do painel analítico.

Na avaliação mensal de 2025, o conjunto de teste tem 60 observações e 37 eventos. As métricas reconstruídas são:

| Métrica | Ridge, C=10 | DTMC |
|---|---:|---:|
| AUROC | 0.866040 | 0.806110 |
| AUPRC | 0.895686 | 0.832924 |
| Brier score | 0.144069 | 0.144607 |
| Log loss | 0.445144 | 0.449162 |

As pequenas diferenças de precisão numérica face a resultados calculados noutras versões de bibliotecas podem ocorrer; os testes comparam as métricas publicadas com tolerância de arredondamento.

## Limites conhecidos

- O livro `processed_inputs/dataset(3).xlsx` é usado apenas como referência de auditoria para o índice e os estados; o painel utilizado pelo modelo é reconstruído a partir dos indicadores mensais.
- A extração original dos preditores contextuais e das horas suplementares não é reconstruída; são preservados como inputs mensais processados.
- A seleção histórica completa dos modelos candidatos e dos hiperparâmetros não é reexecutada. A especificação principal ridge com `C=10` é avaliada de acordo com o procedimento documentado.
- O código constitui uma reconstrução reproduzível da especificação final, não uma recuperação literal de todos os scripts históricos usados durante o desenvolvimento da dissertação.
