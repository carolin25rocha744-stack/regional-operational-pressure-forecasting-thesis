import unittest
from pathlib import Path
import pandas as pd
from sklearn.metrics import roc_auc_score,average_precision_score,brier_score_loss,log_loss
ROOT=Path(__file__).resolve().parents[1]
class ThesisC10Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.p=pd.read_csv(ROOT/'08_results/numerical_results/predictions_primary.csv',parse_dates=['target_month','period'])
    def test_sample(self):
        g=self.p[self.p.stage=='holdout_monthly']
        self.assertEqual((len(g),int(g.y.sum()),g.region.nunique(),g.target_month.nunique()),(60,37,5,12))
        self.assertFalse(g.duplicated(['region','target_month']).any())
    def test_chronology(self):
        self.assertTrue((self.p.target_month>self.p.period).all())
    def test_scores(self):
        d=self.p[self.p.stage=='holdout_monthly']
        exp={'Ridge':(.8660399529964747,.8956858135754746,.1440686814261631,.44514386515895227),
             'DTMC':(.8061104582843712,.8329241940060377,.14460661976255001,.4491616458173002)}
        for m,values in exp.items():
            calc=(roc_auc_score(d.y,d[m]),average_precision_score(d.y,d[m]),brier_score_loss(d.y,d[m]),log_loss(d.y,d[m]))
            for a,b in zip(calc,values):self.assertAlmostEqual(a,b,places=8)
    def test_threshold(self):
        d=self.p[self.p.stage=='holdout_monthly'];pred=d.Ridge>=0.6
        self.assertEqual(int(((d.y==1)&pred).sum()),25)
        self.assertEqual(int(((d.y==1)&~pred).sum()),12)
        self.assertEqual(int(((d.y==0)&pred).sum()),3)
        self.assertEqual(int(((d.y==0)&~pred).sum()),20)
    def test_inputs_unchanged(self):
        import json,hashlib
        hashes=json.loads((ROOT/'09_validation/input_sha256.json').read_text())
        for name,expected in hashes.items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),expected,name)
    def test_raw_to_monthly_equivalence(self):
        import json
        report=json.loads((ROOT/'09_validation/preprocessing_validation.json').read_text())
        self.assertTrue(report['passed'])
        self.assertEqual(report['missing_values'],0)

    def test_analytical_panel_rebuilt_from_intermediate(self):
        import json
        report=json.loads((ROOT/'09_validation/analytical_dataset_validation.json').read_text())
        self.assertTrue(report['passed'])
        self.assertEqual(report['rows'],540)
        self.assertEqual(report['ordinal_state_mismatches'],0)
        self.assertLessEqual(report['max_abs_pressure_index_difference'],1e-10)

if __name__=='__main__':unittest.main()
