# Dicionário de dados

O inventário de colunas, tipos, valores em falta e exemplos está em `data_dictionary_columns.csv`, gerado dos painéis analíticos e contextuais exportados pelo pipeline, sem inferir unidades desconhecidas.

| Variável | Significado |
|---|---|
| `period`, `region` | Mês de observação e região; chave única do painel |
| `total_ed_attendances` | Atendimentos de urgência no mês |
| `high_acuity_manchester_share` | Proporção de elevada gravidade segundo Manchester |
| `ed_admission_share` | Proporção de atendimentos com internamento |
| `mean_waiting_time_triage_to_first_obs` | Tempo médio entre triagem e primeira observação; consultar a fonte para a unidade |
| `inpatient_bed_occupancy_rate` | Taxa de ocupação de camas |
| `admission_prone_ed_load_per_bed` | Carga de urgência propensa a internamento por cama |
| `PI_ref`, `S_ref` | Índice e estado ordinal de referência, com definição 2017–2024 |
| `Y_elevated_ref` | Estado elevado no mês observado, estados 4 ou 5 |
| `target_month`, `target_state`, `target_elevated` | Mês seguinte, estado seguinte e indicador de estado 4–5 no mês seguinte |
| `Ridge`, `DTMC` | Probabilidades previstas por cada modelo nas tabelas de previsões |
| `y`, `stage` | Alvo binário usado na avaliação e segmento da execução |

`regional_monthly_reference.csv` tem 540 observações: cinco regiões e 108 meses de 2017 a 2025. É construído a partir de `02_data_intermediate/pressure_indicators_monthly.csv`; o livro `processed_inputs/dataset(3).xlsx` é usado apenas para verificar a equivalência do índice e dos estados de referência. `context_predictors.csv` contém os preditores contextuais preservados; os sufixos `_t` e `_tplus1` identificam o mês de referência indicado no ficheiro.

O alvo de `regional_monthly_reference_with_target.csv` usa os estados de referência e deixa o último mês de cada região sem alvo. Para validação temporal, o núcleo recalcula a definição de pressão em cada janela de treino: não usar o alvo de referência como substituto dos alvos específicos das janelas. As previsões estão associadas a `target_month`, não ao mês dos preditores.

As fontes originais dos seis indicadores estão em `01_data_raw/sns`, por região. Os inputs de contexto e horas são mensais e estão em `03_analytical_dataset/processed_inputs`.
