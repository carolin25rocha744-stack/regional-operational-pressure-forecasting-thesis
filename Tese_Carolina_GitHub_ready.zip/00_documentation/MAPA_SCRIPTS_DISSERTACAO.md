# Correspondência entre scripts e dissertação

| Script | Etapa | Capítulo / tema |
|---|---|---|
| `00_preprocess_sources.py` e `preprocessing/*.py` | Fontes SNS, limpeza, harmonização e agregação mensal | Methodology — Data Understanding; Data Preparation |
| `01_prepare_analytical_dataset.py` | Construção do índice, estados, alvo e painel analítico a partir dos indicadores regenerados | Methodology — Pressure Representation / Target Construction |
| `02_reproduce_primary_c10.py` e `core/reconstruct.py` | Validação temporal, regressão ridge, benchmarks, DTMC e avaliação de 2025 | Methodology — Modelling / Evaluation; Results — Forecasting |
| `03_secondary_evaluations.py` e `core/supplement.py` | Robustez, calibração e associação exploratória com horas suplementares | Results — Pressure Representation / Secondary Evaluations |
| `04_make_figures.py` | Figuras geradas a partir dos resultados calculados | Results and Discussion |
| `05_export_results.py` | Distribuição das tabelas e previsões por etapa | Results and Discussion |
| `09_validation/test_scores.py` | Verificação computacional dos resultados e das entradas | Reproducibility / Validation |

`run_all.py` coordena a execução. `scripts/core` contém as funções analíticas comuns. A correspondência é temática, sem pressupor a paginação de uma versão particular do PDF.

O livro `processed_inputs/dataset(3).xlsx` é usado como referência de auditoria para comparar o índice e os estados; os indicadores operacionais usados na modelação são lidos do painel reconstruído em `02_data_intermediate`. A seleção histórica completa de hiperparâmetros não está implementada neste pacote.
