# Passos de execução

Executar `python run_all.py` na raiz do projeto. Os passos são chamados pela ordem abaixo; não executar as etapas dependentes antes dos seus inputs estarem disponíveis.

1. `python scripts/00_preprocess_sources.py` — lê as 30 fontes SNS em `01_data_raw`, limpa e agrega os indicadores mensais em `02_data_intermediate`, e verifica a equivalência com os indicadores preservados no livro de referência. Os scripts regionais de suporte estão em `scripts/preprocessing/`.
2. `python scripts/01_prepare_analytical_dataset.py` — lê `02_data_intermediate/pressure_indicators_monthly.csv`, calcula o índice contínuo e os estados ordinais com parâmetros de 2017–2024, compara-os com o livro de referência preservado, e gera o painel analítico e a variável-alvo do mês seguinte.
3. `python scripts/02_reproduce_primary_c10.py` — executa validação temporal de 2021–2024, previsões mensais de 2025, benchmark DTMC, análise de episódios, transições, bootstrap e avaliação geográfica.
4. `python scripts/03_secondary_evaluations.py` — calcula robustez do índice, calibração e análise exploratória das horas suplementares.
5. `python scripts/04_make_figures.py` — cria as figuras PNG e SVG a partir dos resultados recém-calculados.
6. `python scripts/05_export_results.py` — distribui os resultados numéricos pelas pastas de análise, desenvolvimento, avaliação final e avaliações secundárias.
7. `python -m unittest discover -s 09_validation -p 'test_*.py' -v` — verifica cronologia, amostra de 2025, métricas ridge–DTMC, classificação ao limiar 0,6, integridade das entradas, equivalência dos indicadores e reconstrução do painel analítico.

A limpeza SNS e a construção do painel analítico são reconstruídas a partir de `01_data_raw`. Os ficheiros `exo(2).xlsx` e `horas.xlsx` continuam a ser inputs mensais processados; a sua extração desde fontes externas não é reconstruída. A seleção histórica completa dos modelos candidatos também não é reproduzida.

Os resultados publicados no pacote foram verificados em Python 3.13.5 com as versões listadas em `requirements.txt`. A instalação a partir de um ambiente virtual novo não foi testada de forma independente.
