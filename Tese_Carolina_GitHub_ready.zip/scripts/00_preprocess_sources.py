"""Regenera os seis indicadores mensais a partir das fontes SNS."""
from pathlib import Path
import subprocess,sys,json,tempfile,os
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
FEATURES=['total_ed_attendances','high_acuity_manchester_share','ed_admission_share','mean_waiting_time_triage_to_first_obs','inpatient_bed_occupancy_rate','admission_prone_ed_load_per_bed']
def main():
    out=ROOT/'02_data_intermediate';out.mkdir(exist_ok=True)
    panels=[]
    names=['total_ed_attendances','high_acuity_manchester_share','ed_admission_share','mean_waiting_time','downstream_capacity']
    monthly={name:[] for name in names}
    with tempfile.TemporaryDirectory(prefix='thesis_preprocess_') as tmp:
        env=dict(os.environ,THESIS_PREPROCESS_WORKDIR=tmp)
        for region in ['alentejo','algarve','centro','lvt','norte']:
            with (Path(tmp)/(region+'.log')).open('w') as log:
                result=subprocess.run([sys.executable,str(ROOT/'scripts/preprocessing'/(region+'.py'))],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=env)
            if result.returncode:
                message=(Path(tmp)/(region+'.log')).read_text()
                raise RuntimeError(message)
            folder=Path(tmp)/region/'clean'
            panels.append(pd.read_csv(folder/(region+'_pressure_index_indicators_monthly.csv'),parse_dates=['period']))
            for name in names:
                a=pd.read_excel(folder/(region+'_'+name+'_monthly.xlsx'))
                if 'region' not in a:a['region']=panels[-1].region.iloc[0]
                monthly[name].append(a)
        panel=pd.concat(panels,ignore_index=True).sort_values(['region','period']).reset_index(drop=True)
        panel.to_csv(out/'pressure_indicators_monthly.csv',index=False)
        for i,name in enumerate(names,1):pd.concat(monthly[name],ignore_index=True).to_csv(out/(f'{i:02d}_'+name+'_monthly.csv'),index=False)
    ref=pd.read_excel(ROOT/'03_analytical_dataset/processed_inputs/dataset(3).xlsx').sort_values(['region','period']).reset_index(drop=True)
    report={'same_keys':panel[['region','period']].equals(ref[['region','period']]),'max_abs_difference':{f:float(np.nanmax(abs(panel[f]-ref[f]))) for f in FEATURES},'missing_values':int(panel[FEATURES].isna().sum().sum())}
    report['passed']=bool(report['same_keys'] and report['missing_values']==0 and np.allclose(panel[FEATURES],ref[FEATURES],rtol=1e-8,atol=1e-8))
    (ROOT/'09_validation/preprocessing_validation.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    if not report['passed']:raise SystemExit('Os indicadores diferem das entradas mensais; consultar relatório.')
if __name__=='__main__':main()
