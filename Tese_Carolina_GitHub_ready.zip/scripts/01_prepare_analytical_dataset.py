"""Build the analytical panel from the outputs of the raw-data preprocessing stage."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
FEATURES = [
    "total_ed_attendances",
    "high_acuity_manchester_share",
    "ed_admission_share",
    "mean_waiting_time_triage_to_first_obs",
    "inpatient_bed_occupancy_rate",
    "admission_prone_ed_load_per_bed",
]

def build_reference_panel(panel):
    """Construct the reference pressure index and ordinal states from the six rebuilt indicators."""
    df = panel.copy()
    df["period"] = pd.to_datetime(df["period"], errors="raise")
    df = df.sort_values(["region", "period"]).reset_index(drop=True)

    if len(df) != 540:
        raise ValueError(f"Expected 540 region-month rows, got {len(df)}.")
    if df.duplicated(["region", "period"]).any():
        raise ValueError("Duplicate region-month keys in intermediate panel.")
    if df[FEATURES].isna().any().any():
        raise ValueError("Missing values in one or more of the six operational indicators.")

    development = df["period"].dt.year < 2025
    mu = df.loc[development, FEATURES].mean()
    sd = df.loc[development, FEATURES].std(ddof=0)
    if (sd == 0).any() or sd.isna().any():
        raise ValueError("Cannot standardize an indicator with zero or undefined development-period SD.")

    z = (df[FEATURES] - mu) / sd
    df["PI_ref"] = z.mean(axis=1)

    states = pd.Series(index=df.index, dtype="int64")
    cutpoints = {}
    for region in sorted(df["region"].unique()):
        mask = df["region"].eq(region)
        q = np.quantile(
            df.loc[mask & development, "PI_ref"],
            [0.2, 0.4, 0.6, 0.8],
            method="linear",
        )
        states.loc[mask] = np.searchsorted(q, df.loc[mask, "PI_ref"], side="left") + 1
        cutpoints[region] = q.tolist()

    df["S_ref"] = states.astype(int)
    df["Y_elevated_ref"] = (df["S_ref"] >= 4).astype(int)
    df["sample_segment"] = np.where(df["period"].dt.year < 2025, "development", "holdout")

    cols = ["period", "region", "sample_segment", "PI_ref", "S_ref", "Y_elevated_ref"] + FEATURES
    params = {
        "development_period": "2017-01 to 2024-12",
        "holdout_period": "2025-01 to 2025-12",
        "standardization": "indicator-wise pooled z-scores, means and population SDs estimated on 2017-2024",
        "index": "unweighted mean of the six standardized indicators",
        "ordinal_states": "region-specific 2017-2024 quintile cutpoints; state 5 is highest pressure",
        "means": mu.to_dict(),
        "std_ddof0": sd.to_dict(),
        "cutpoints_by_region": cutpoints,
    }
    return df[cols], params

def main():
    analytical = ROOT / "03_analytical_dataset"
    inputs = analytical / "processed_inputs"
    intermediate_path = ROOT / "02_data_intermediate" / "pressure_indicators_monthly.csv"
    if not intermediate_path.exists():
        raise FileNotFoundError(
            f"Missing {intermediate_path}. Run scripts/00_preprocess_sources.py first."
        )

    # This panel is generated from 01_data_raw by scripts/00_preprocess_sources.py.
    panel = pd.read_csv(intermediate_path, parse_dates=["period"])
    rebuilt, params = build_reference_panel(panel)

    # The preserved workbook is used only as an independent reference for audit.
    reference = pd.read_excel(inputs / "dataset(3).xlsx")
    reference["period"] = pd.to_datetime(reference["period"], errors="raise")
    reference = reference.sort_values(["region", "period"]).reset_index(drop=True)
    reference = reference[["period", "region", "PI_ref", "S_ref"] + FEATURES]

    candidate = rebuilt.sort_values(["region", "period"]).reset_index(drop=True)
    same_keys = candidate[["region", "period"]].equals(reference[["region", "period"]])
    max_feature_difference = {
        feature: float(np.max(np.abs(
            candidate[feature].to_numpy(dtype=float) - reference[feature].to_numpy(dtype=float)
        )))
        for feature in FEATURES
    }
    max_pi_difference = float(np.max(np.abs(candidate["PI_ref"] - reference["PI_ref"])))
    state_mismatches = int((candidate["S_ref"].to_numpy() != reference["S_ref"].to_numpy()).sum())
    report = {
        "passed": bool(
            same_keys
            and max(max_feature_difference.values()) <= 1e-8
            and max_pi_difference <= 1e-10
            and state_mismatches == 0
        ),
        "source_for_analytical_panel": "02_data_intermediate/pressure_indicators_monthly.csv",
        "reference_only": "03_analytical_dataset/processed_inputs/dataset(3).xlsx",
        "same_region_month_keys": bool(same_keys),
        "max_abs_indicator_difference": max_feature_difference,
        "max_abs_pressure_index_difference": max_pi_difference,
        "ordinal_state_mismatches": state_mismatches,
        "rows": int(len(candidate)),
        "regions": int(candidate["region"].nunique()),
        "months_per_region": {
            str(k): int(v) for k, v in candidate.groupby("region")["period"].nunique().items()
        },
    }
    (ROOT / "09_validation").mkdir(exist_ok=True)
    (ROOT / "09_validation" / "analytical_dataset_validation.json").write_text(
        json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    if not report["passed"]:
        raise SystemExit("Rebuilt analytical panel differs from the preserved reference; see analytical_dataset_validation.json.")

    rebuilt.to_csv(analytical / "regional_monthly_reference.csv", index=False)

    # Context variables remain a preserved processed input; they are not part of the primary six-feature model.
    ex = pd.read_excel(inputs / "exo(2).xlsx")
    ex.to_csv(analytical / "context_predictors.csv", index=False)

    target = rebuilt.sort_values(["region", "period"]).copy()
    g = target.groupby("region", sort=False)
    target["target_month"] = g["period"].shift(-1)
    target["target_state"] = g["S_ref"].shift(-1)
    target["target_elevated"] = (target["target_state"] >= 4).astype("Int64").mask(target["target_state"].isna())
    target.to_csv(analytical / "regional_monthly_reference_with_target.csv", index=False)

    dictionary = []
    for dataset_name, frame in [
        ("regional_monthly_reference.csv", rebuilt),
        ("context_predictors.csv", ex),
        ("regional_monthly_reference_with_target.csv", target),
    ]:
        for col in frame.columns:
            s = frame[col]
            dictionary.append({
                "dataset": dataset_name,
                "variable": col,
                "dtype": str(s.dtype),
                "non_null": int(s.notna().sum()),
                "missing": int(s.isna().sum()),
                "unique": int(s.nunique(dropna=True)),
                "example": str(s.dropna().iloc[0]) if s.notna().any() else "",
            })
    pd.DataFrame(dictionary).to_csv(
        ROOT / "00_documentation" / "data_dictionary_columns.csv", index=False
    )
    (analytical / "pressure_index_parameters.json").write_text(
        json.dumps(params, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print("Analytical panel generated from rebuilt monthly indicators.")

if __name__ == "__main__":
    main()
