from pathlib import Path
import os
ROOT = Path(__file__).resolve().parents[2]
import matplotlib
matplotlib.use("Agg")
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "alentejo"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "alentejo"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "alentejo" / "total_ed_attendances"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

file_path = RAW_DIR / "total_attendences.xlsx"

# ============================================================
# Region and indicator definitions
# ============================================================

REGION_RAW = "ARS Alentejo"
REGION_NAME = "Região de Saúde do Alentejo"
REGION_SLUG = "alentejo"

INDICATOR_NAME = "Número estimado de episódios de urgência"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-31")

# ============================================================
# 1. Load data
# ============================================================

df = pd.read_excel(file_path)

df = df.rename(columns={
    "Período": "date",
    "Região/ARS": "region_raw",
    "Indicador": "indicator",
    "Valor": "value",
    "Unidade": "unit",
    "ID": "id"
})

df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["value"] = pd.to_numeric(df["value"], errors="coerce")

print("\n=== AVAILABLE REGIONS ===")
print(df["region_raw"].dropna().unique())

print("\n=== AVAILABLE INDICATORS ===")
print(df["indicator"].dropna().unique())

# ============================================================
# 2. Filter indicator, region, and study period
# ============================================================

df = df[
    (df["region_raw"] == REGION_RAW) &
    (df["indicator"] == INDICATOR_NAME) &
    (df["date"] >= START_DATE) &
    (df["date"] <= END_DATE)
].copy()

if df.empty:
    raw = pd.read_excel(file_path)
    raise ValueError(
        "No rows found after filtering. Check REGION_RAW and INDICATOR_NAME.\n\n"
        f"Available regions:\n{raw['Região/ARS'].dropna().unique()}\n\n"
        f"Available indicators:\n{raw['Indicador'].dropna().unique()}"
    )

df = df.sort_values("date").reset_index(drop=True)

# ============================================================
# 3. Raw checks
# ============================================================

print("\n=== RAW DATA CHECKS ===")
print("Rows:", len(df))
print("Date range:", df["date"].min(), "to", df["date"].max())
print("Duplicated dates:", df.duplicated(subset=["date", "region_raw", "indicator"]).sum())
print("Missing dates:", df["date"].isna().sum())
print("Missing values:", df["value"].isna().sum())
print("Unit:", df["unit"].dropna().unique())

full_daily_range = pd.date_range(START_DATE, END_DATE, freq="D")
missing_days = sorted(set(full_daily_range) - set(df["date"]))

print("Expected number of days:", len(full_daily_range))
print("Observed number of days:", df["date"].nunique())
print("Missing calendar days:", len(missing_days))

missing_days_df = pd.DataFrame({"missing_date": missing_days})
missing_days_path = EDA_DIR / f"{REGION_SLUG}_total_ed_attendances_missing_daily_audit.xlsx"
missing_days_df.to_excel(missing_days_path, index=False)

print("Saved missing-day audit to:")
print(missing_days_path)

# ============================================================
# 4. Aggregate daily emergency attendances to monthly totals
# ============================================================

df["period"] = df["date"].dt.to_period("M").dt.to_timestamp()

monthly = (
    df.groupby("period", as_index=False)
      .agg(
          total_ed_attendances_observed=("value", "sum"),
          n_days_reported=("date", "nunique")
      )
)

monthly["region"] = REGION_NAME
monthly["days_in_month"] = monthly["period"].dt.days_in_month
monthly["complete_month"] = monthly["n_days_reported"] == monthly["days_in_month"]
monthly["coverage_share"] = monthly["n_days_reported"] / monthly["days_in_month"]

# Adjust daily-count variable for incomplete monthly coverage.
# For complete months, this equals the observed monthly total.
monthly["total_ed_attendances"] = (
    monthly["total_ed_attendances_observed"] / monthly["coverage_share"]
)

monthly["total_ed_attendances_adjusted"] = ~monthly["complete_month"]

monthly["year"] = monthly["period"].dt.year
monthly["month"] = monthly["period"].dt.month

monthly = monthly[
    [
        "period",
        "region",
        "total_ed_attendances",
        "total_ed_attendances_observed",
        "n_days_reported",
        "days_in_month",
        "coverage_share",
        "complete_month",
        "total_ed_attendances_adjusted",
        "year",
        "month"
    ]
].sort_values("period").reset_index(drop=True)

# ============================================================
# 5. Monthly checks
# ============================================================

print("\n=== MONTHLY DATASET ===")
print(monthly.head())
print(monthly.tail())

print("\nCoverage:")
print(monthly["period"].min(), "to", monthly["period"].max())
print("Number of months:", len(monthly))
print("Incomplete months:", (~monthly["complete_month"]).sum())

expected_months = pd.date_range("2017-01-01", "2025-12-01", freq="MS")
missing_months = sorted(set(expected_months) - set(monthly["period"]))

print("\nMissing months:")
print(missing_months if missing_months else "No missing months.")

print("\nIncomplete months:")
incomplete = monthly.loc[
    monthly["complete_month"] == False,
    [
        "period",
        "total_ed_attendances",
        "total_ed_attendances_observed",
        "n_days_reported",
        "days_in_month",
        "coverage_share"
    ]
]
print(incomplete if not incomplete.empty else "No incomplete months found.")

print("\nDescriptive statistics:")
print(monthly[
    [
        "total_ed_attendances",
        "total_ed_attendances_observed",
        "coverage_share"
    ]
].describe())

if monthly["total_ed_attendances"].isna().sum() > 0:
    raise ValueError("The final total_ed_attendances contains missing values.")

# ============================================================
# 6. Save clean files
# ============================================================

out_csv = CLEAN_DIR / f"{REGION_SLUG}_total_ed_attendances_monthly.csv"
out_xlsx = CLEAN_DIR / f"{REGION_SLUG}_total_ed_attendances_monthly.xlsx"

monthly.to_csv(out_csv, index=False)
monthly.to_excel(out_xlsx, index=False)

print("\nSaved files to:")
print(out_csv)
print(out_xlsx)

# ============================================================
# 7. EDA plot
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["total_ed_attendances"],
    marker="o",
    linewidth=1,
    label="Adjusted monthly total"
)

plt.plot(
    monthly["period"],
    monthly["total_ed_attendances_observed"],
    marker="o",
    linewidth=0.8,
    linestyle="--",
    label="Observed monthly total"
)

plt.title("Alentejo - Total emergency department attendances")
plt.xlabel("Month")
plt.ylabel("Monthly ED attendances")
plt.grid(True, alpha=0.3)
plt.legend()
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_total_ed_attendances_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

# ============================================================
# 8. Coverage plot
# ============================================================

plt.figure(figsize=(11, 3.5))
plt.plot(
    monthly["period"],
    monthly["coverage_share"],
    marker="o",
    linewidth=1
)

plt.axhline(1.0, linewidth=1)
plt.title("Alentejo - Daily coverage share for total ED attendances")
plt.xlabel("Month")
plt.ylabel("Coverage share")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_total_ed_attendances_coverage_share.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths and region settings
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "alentejo"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "alentejo"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "alentejo" / "high_acuity"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

file_path = RAW_DIR / "data 7 final" / "high_acuity.xlsx"

if not file_path.exists():
    file_path = RAW_DIR / "high_acuity.xlsx"

REGION_RAW = "Região de Saúde do Alentejo"
REGION_NAME = "Região de Saúde do Alentejo"
REGION_SLUG = "alentejo"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-01")

# ============================================================
# Helper functions
# ============================================================

def parse_month_column(series):
    return pd.to_datetime(
        series.astype(str).str.slice(0, 7) + "-01",
        errors="coerce"
    )

def save_audit(df, path):
    df.to_excel(path, index=False)

# ============================================================
# 1. Load data
# ============================================================

if not file_path.exists():
    raise FileNotFoundError(f"File not found: {file_path}")

df = pd.read_excel(file_path)

df = df.rename(columns={
    "Período": "period",
    "Região": "region_raw",
    "Instituição": "institution",
    "Localização Geográfica": "geo",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Vermelha": "red_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Laranja": "orange_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Amarela": "yellow_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Verde": "green_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Azul": "blue_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Branca": "white_cum",
    "Nº Atendimentos s\\ Triagem Manchester": "no_triage_cum"
})

required_cols = [
    "period",
    "region_raw",
    "institution",
    "red_cum",
    "orange_cum",
    "yellow_cum",
    "green_cum",
    "blue_cum",
    "white_cum",
    "no_triage_cum"
]

missing_required_cols = [col for col in required_cols if col not in df.columns]

if missing_required_cols:
    raise ValueError(
        f"Missing required columns: {missing_required_cols}\n"
        f"Available columns: {df.columns.tolist()}"
    )

df["period"] = parse_month_column(df["period"])

count_cum_cols = [
    "red_cum",
    "orange_cum",
    "yellow_cum",
    "green_cum",
    "blue_cum",
    "white_cum",
    "no_triage_cum"
]

main_manchester_cum_cols = [
    "red_cum",
    "orange_cum",
    "yellow_cum",
    "green_cum",
    "blue_cum",
    "white_cum"
]

for col in count_cum_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# ============================================================
# 2. Region validation and filtering
# ============================================================

available_regions = sorted(df["region_raw"].dropna().unique())

print("\n=== AVAILABLE REGIONS IN FILE ===")
for region in available_regions:
    print("-", region)

if REGION_RAW not in available_regions:
    raise ValueError(
        f"Selected region '{REGION_RAW}' not found in file. "
        f"Available regions: {available_regions}"
    )

df = df[
    (df["region_raw"] == REGION_RAW) &
    (df["period"] >= START_DATE) &
    (df["period"] <= END_DATE)
].copy()

df = df.sort_values(["institution", "period"]).reset_index(drop=True)

df["year"] = df["period"].dt.year
df["month"] = df["period"].dt.month

print("\n=== FILTERED DATA CHECKS ===")
print("Region:", REGION_RAW)
print("Rows:", len(df))
print("Institutions:", df["institution"].nunique())
print("Period:", df["period"].min(), "to", df["period"].max())

if len(df) == 0:
    raise ValueError("No rows after filtering. Check region name, date range, or source file.")
# ============================================================
# 3. Raw missing-value audit
# ============================================================

raw_missing = df.loc[
    df[count_cum_cols].isna().any(axis=1),
    ["period", "institution"] + count_cum_cols
].copy()

raw_missing_path = EDA_DIR / f"{REGION_SLUG}_manchester_raw_missing_audit.xlsx"
save_audit(raw_missing, raw_missing_path)

print("\n=== RAW MISSING VALUE CHECK ===")
print("Rows with at least one missing cumulative count:", len(raw_missing))
print("Missing values by variable:")
print(df[count_cum_cols].isna().sum())
print("Saved raw missing audit to:", raw_missing_path)

# ============================================================
# 4. Missing-value treatment
# ============================================================

df_filled = df.copy()
missing_treatments = []

for (institution, year), idx in df_filled.groupby(["institution", "year"], dropna=False).groups.items():
    idx = list(idx)
    g = df_filled.loc[idx].sort_values("period")

    main_has_any_data = g[main_manchester_cum_cols].notna().any().any()

    for col in count_cum_cols:
        s = g[col].astype(float)
        n_missing_before = int(s.isna().sum())

        if not main_has_any_data:
            s_filled = pd.Series(0.0, index=g.index)
            treatment = "institution_year_without_main_colours_set_to_zero"

        elif s.isna().all():
            s_filled = pd.Series(0.0, index=g.index)
            treatment = "entire_category_missing_set_to_zero"

        else:
            s_filled = s.interpolate(method="linear", limit_area="inside")
            s_filled = s_filled.ffill()
            s_filled = s_filled.fillna(0.0)
            treatment = "interpolate_internal_then_ffill_or_zero_leading"

        n_missing_after = int(s_filled.isna().sum())
        n_treated = n_missing_before - n_missing_after

        if n_treated > 0 or treatment in [
            "institution_year_without_main_colours_set_to_zero",
            "entire_category_missing_set_to_zero"
        ]:
            missing_treatments.append({
                "institution": institution,
                "year": year,
                "variable": col,
                "treatment": treatment,
                "n_values_treated": n_treated if n_treated > 0 else len(g)
            })

        df_filled.loc[g.index, col] = s_filled

missing_treatments_df = pd.DataFrame(missing_treatments)
missing_treatments_path = EDA_DIR / f"{REGION_SLUG}_manchester_missing_treatment_audit.xlsx"
save_audit(missing_treatments_df, missing_treatments_path)

remaining_missing = df_filled.loc[
    df_filled[count_cum_cols].isna().any(axis=1),
    ["period", "institution", "year"] + count_cum_cols
].copy()

remaining_missing_path = EDA_DIR / f"{REGION_SLUG}_manchester_remaining_missing_after_treatment.xlsx"
save_audit(remaining_missing, remaining_missing_path)

print("\n=== MISSING VALUE TREATMENT ===")
print("Missing-value treatments:", len(missing_treatments_df))
print("Rows still containing missing values:", len(remaining_missing))
print("Remaining missing values by variable:")
print(df_filled[count_cum_cols].isna().sum())
print("Saved treatment audit to:", missing_treatments_path)
print("Saved remaining missing audit to:", remaining_missing_path)

# ============================================================
# 5. Cumulative behaviour audit at institution-year level
# ============================================================

cumulative_decrease_records = []

for (institution, year), g in df_filled.groupby(["institution", "year"], dropna=False):
    g = g.sort_values("period")

    for col in count_cum_cols:
        diff = g[col].diff()
        decreases = g.loc[diff < -1e-9, ["period", "institution", col]].copy()

        for _, row in decreases.iterrows():
            previous_rows = g.loc[g["period"] < row["period"], col]

            cumulative_decrease_records.append({
                "institution": institution,
                "year": year,
                "period": row["period"],
                "variable": col,
                "value": row[col],
                "previous_value": previous_rows.iloc[-1] if len(previous_rows) else np.nan,
                "decrease": row[col] - (previous_rows.iloc[-1] if len(previous_rows) else np.nan)
            })

cumulative_decrease_audit = pd.DataFrame(cumulative_decrease_records)
cumulative_decrease_path = EDA_DIR / f"{REGION_SLUG}_manchester_cumulative_decrease_audit.xlsx"
save_audit(cumulative_decrease_audit, cumulative_decrease_path)

print("\n=== CUMULATIVE BEHAVIOUR CHECK ===")
print("Institution-year cumulative decreases found:", len(cumulative_decrease_audit))
print("Saved cumulative decrease audit to:", cumulative_decrease_path)

# ============================================================
# 6. Reconstruct true monthly counts
# ============================================================

monthly_parts = []
negative_flow_records = []

for (institution, year), g in df_filled.groupby(["institution", "year"], dropna=False):
    g = g.sort_values("period").copy()

    out = g[["period", "year", "month", "region_raw", "institution"]].copy()

    for cum_col in count_cum_cols:
        monthly_col = cum_col.replace("_cum", "_monthly")

        flow = g[cum_col].diff()
        first_idx = flow.index[0]
        flow.loc[first_idx] = g.loc[first_idx, cum_col]

        neg_mask = flow < -1e-9

        if neg_mask.any():
            for idx_neg in flow[neg_mask].index:
                negative_flow_records.append({
                    "institution": institution,
                    "year": year,
                    "period": g.loc[idx_neg, "period"],
                    "variable": cum_col,
                    "cumulative_value": g.loc[idx_neg, cum_col],
                    "raw_monthly_flow": flow.loc[idx_neg],
                    "treatment": "negative_monthly_flow_clipped_to_zero"
                })

            flow.loc[neg_mask] = 0.0

        out[monthly_col] = flow

    monthly_parts.append(out)

institution_monthly = pd.concat(monthly_parts, ignore_index=True)

negative_flow_audit = pd.DataFrame(negative_flow_records)
negative_flow_path = EDA_DIR / f"{REGION_SLUG}_manchester_negative_monthly_flow_audit.xlsx"
save_audit(negative_flow_audit, negative_flow_path)

print("\n=== MONTHLY FLOW RECONSTRUCTION ===")
print("Negative monthly flows clipped to zero:", len(negative_flow_audit))
print("Saved negative monthly flow audit to:", negative_flow_path)

monthly_count_cols = {
    "red_monthly": "red_manchester_attendances",
    "orange_monthly": "orange_manchester_attendances",
    "yellow_monthly": "yellow_manchester_attendances",
    "green_monthly": "green_manchester_attendances",
    "blue_monthly": "blue_manchester_attendances",
    "white_monthly": "white_manchester_attendances",
    "no_triage_monthly": "no_manchester_triage_attendances"
}

institution_monthly = institution_monthly.rename(columns=monthly_count_cols)

regional_monthly_cols = list(monthly_count_cols.values())

regional_monthly = (
    institution_monthly
    .groupby(["period"], as_index=False)[regional_monthly_cols]
    .sum(min_count=1)
    .sort_values("period")
)

regional_monthly["region"] = REGION_NAME

# ============================================================
# 7. Coverage check
# ============================================================

expected_months = pd.date_range(START_DATE, END_DATE, freq="MS")
observed_months = set(regional_monthly["period"])
missing_months = [m for m in expected_months if m not in observed_months]

missing_months_df = pd.DataFrame({"missing_period": missing_months})
missing_months_path = EDA_DIR / f"{REGION_SLUG}_manchester_missing_region_months.xlsx"
save_audit(missing_months_df, missing_months_path)

print("\n=== MONTHLY COVERAGE CHECK ===")
print("Expected months:", len(expected_months))
print("Observed months:", regional_monthly["period"].nunique())
print("Missing region-months:", len(missing_months))
print("Saved missing month audit to:", missing_months_path)

# ============================================================
# 8. Construct high-acuity Manchester share
# ============================================================

known_cols = [
    "red_manchester_attendances",
    "orange_manchester_attendances",
    "yellow_manchester_attendances",
    "green_manchester_attendances",
    "blue_manchester_attendances",
    "white_manchester_attendances"
]

regional_monthly["known_manchester_attendances"] = (
    regional_monthly[known_cols].sum(axis=1)
)

regional_monthly["high_acuity_manchester_attendances"] = (
    regional_monthly["red_manchester_attendances"] +
    regional_monthly["orange_manchester_attendances"]
)

regional_monthly["high_acuity_manchester_share"] = np.where(
    regional_monthly["known_manchester_attendances"] > 0,
    regional_monthly["high_acuity_manchester_attendances"] /
    regional_monthly["known_manchester_attendances"],
    np.nan
)

regional_monthly["total_with_or_without_manchester_triage"] = (
    regional_monthly["known_manchester_attendances"] +
    regional_monthly["no_manchester_triage_attendances"]
)

regional_monthly["manchester_triage_coverage_share"] = np.where(
    regional_monthly["total_with_or_without_manchester_triage"] > 0,
    regional_monthly["known_manchester_attendances"] /
    regional_monthly["total_with_or_without_manchester_triage"],
    np.nan
)

# ============================================================
# 9. Final dataset and final checks
# ============================================================

regional_monthly["year"] = regional_monthly["period"].dt.year
regional_monthly["month"] = regional_monthly["period"].dt.month

final_cols = [
    "period",
    "region",
    "red_manchester_attendances",
    "orange_manchester_attendances",
    "yellow_manchester_attendances",
    "green_manchester_attendances",
    "blue_manchester_attendances",
    "white_manchester_attendances",
    "no_manchester_triage_attendances",
    "known_manchester_attendances",
    "high_acuity_manchester_attendances",
    "high_acuity_manchester_share",
    "manchester_triage_coverage_share",
    "year",
    "month"
]

monthly_final = (
    regional_monthly[final_cols]
    .sort_values("period")
    .reset_index(drop=True)
)

print("\n=== FINAL MONTHLY DATASET CHECK ===")
print(monthly_final.head())
print(monthly_final.tail())

print("\nPeriod:", monthly_final["period"].min(), "to", monthly_final["period"].max())
print("Number of months:", len(monthly_final))

print("\nMissing values in final dataset:")
print(monthly_final.isna().sum())

print("\nHigh-acuity Manchester share summary:")
print(monthly_final["high_acuity_manchester_share"].describe())

print("\nManchester triage coverage summary:")
print(monthly_final["manchester_triage_coverage_share"].describe())

if monthly_final["high_acuity_manchester_share"].isna().sum() > 0:
    print("\nWARNING: high_acuity_manchester_share contains missing values. Inspect audits before using in the index.")
else:
    print("\nOK: high_acuity_manchester_share has no missing values.")

# ============================================================
# 10. Save clean files
# ============================================================

out_csv = CLEAN_DIR / f"{REGION_SLUG}_high_acuity_manchester_share_monthly.csv"
out_xlsx = CLEAN_DIR / f"{REGION_SLUG}_high_acuity_manchester_share_monthly.xlsx"

monthly_final.to_csv(out_csv, index=False)
monthly_final.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 11. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly_final["period"],
    monthly_final["high_acuity_manchester_share"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - High-acuity Manchester share")
plt.xlabel("Month")
plt.ylabel("High-acuity share: red + orange / known Manchester-coded attendances")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_high_acuity_manchester_share_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:", fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly_final["period"],
    monthly_final["manchester_triage_coverage_share"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Manchester triage coverage share")
plt.xlabel("Month")
plt.ylabel("Known Manchester-coded attendances / total attendances in this dataset")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_manchester_triage_coverage_share_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:", fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "alentejo"

RAW_DIR = ROOT / "01_data_raw" / "sns" / "alentejo"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "alentejo" / "ed_admission_share"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

admission_file = RAW_DIR / "inpatients.xlsx"
attendances_file = RAW_DIR / "total_attendences.xlsx"

REGION_RAW = "ARS Alentejo"
REGION_NAME = "Região de Saúde do Alentejo"
REGION_SLUG = "alentejo"

ADMISSION_INDICATOR = "Taxa diária de atendimentos urgentes com internamento"
ATTENDANCES_INDICATOR = "Número estimado de episódios de urgência"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-31")

# ============================================================
# Helper functions
# ============================================================

def read_sns_daily_file(file_path, value_name):
    df = pd.read_excel(file_path)

    df = df.rename(columns={
        "Período": "date",
        "Região/ARS": "region_raw",
        "Indicador": "indicator",
        "Valor": value_name,
        "Unidade": "unit",
        "ID": "id"
    })

    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df[value_name] = pd.to_numeric(df[value_name], errors="coerce")

    return df

# ============================================================
# 1. Load daily admission-rate variable: variable 528
# ============================================================

adm = read_sns_daily_file(admission_file, "ed_admission_rate_raw")

print("\n=== AVAILABLE REGIONS IN ADMISSION FILE ===")
print(adm["region_raw"].dropna().unique())

adm = adm[
    (adm["region_raw"] == REGION_RAW) &
    (adm["indicator"] == ADMISSION_INDICATOR) &
    (adm["date"] >= START_DATE) &
    (adm["date"] <= END_DATE)
].copy()

if len(adm) == 0:
    raise ValueError(
        f"No rows found for region '{REGION_RAW}' and indicator '{ADMISSION_INDICATOR}'. "
        "Check the region name or input file."
    )

adm = adm.sort_values("date").reset_index(drop=True)

# Safety conversion:
# If values are reported as percentages, e.g. 9.5, convert to 0.095.
# If already reported as proportions, e.g. 0.095, keep unchanged.
max_adm_value = adm["ed_admission_rate_raw"].max()

if max_adm_value > 1.5:
    adm["ed_admission_share_daily"] = adm["ed_admission_rate_raw"] / 100
    adm["ed_admission_pct_daily"] = adm["ed_admission_rate_raw"]
else:
    adm["ed_admission_share_daily"] = adm["ed_admission_rate_raw"]
    adm["ed_admission_pct_daily"] = adm["ed_admission_rate_raw"] * 100

adm = (
    adm.groupby("date", as_index=False)
       .agg(
           ed_admission_share_daily=("ed_admission_share_daily", "mean"),
           ed_admission_pct_daily=("ed_admission_pct_daily", "mean")
       )
       .sort_values("date")
)

# ============================================================
# 2. Load daily total ED attendances: variable 531
# ============================================================

att = read_sns_daily_file(attendances_file, "total_ed_attendances_daily")

print("\n=== AVAILABLE REGIONS IN ATTENDANCES FILE ===")
print(att["region_raw"].dropna().unique())

att = att[
    (att["region_raw"] == REGION_RAW) &
    (att["indicator"] == ATTENDANCES_INDICATOR) &
    (att["date"] >= START_DATE) &
    (att["date"] <= END_DATE)
].copy()

if len(att) == 0:
    raise ValueError(
        f"No rows found for region '{REGION_RAW}' and indicator '{ATTENDANCES_INDICATOR}'. "
        "Check the region name or input file."
    )

att = (
    att.groupby("date", as_index=False)
       .agg(total_ed_attendances_daily=("total_ed_attendances_daily", "sum"))
       .sort_values("date")
)

# ============================================================
# 3. Merge daily rate with daily attendances
# ============================================================

daily = pd.DataFrame({
    "date": pd.date_range(START_DATE, END_DATE, freq="D")
})

daily = daily.merge(adm, on="date", how="left")
daily = daily.merge(att, on="date", how="left")

daily["observed_admission_share"] = daily["ed_admission_share_daily"].notna()
daily["observed_total_attendances"] = daily["total_ed_attendances_daily"].notna()

# ============================================================
# 4. Missing-day audit before imputation
# ============================================================

daily["missing_any_source"] = (
    daily["ed_admission_share_daily"].isna() |
    daily["total_ed_attendances_daily"].isna()
)

missing_days = daily.loc[
    daily["missing_any_source"],
    [
        "date",
        "ed_admission_share_daily",
        "total_ed_attendances_daily",
        "observed_admission_share",
        "observed_total_attendances"
    ]
].copy()

missing_days_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_missing_daily_audit_before_imputation.xlsx"
missing_days.to_excel(missing_days_path, index=False)

print("\n=== DAILY MISSING CHECK BEFORE IMPUTATION ===")
print("Missing days in at least one source:", len(missing_days))
print(missing_days.head(30))
print("Saved missing-day audit to:", missing_days_path)

# ============================================================
# 5. Impute missing daily values
# ============================================================

daily = daily.sort_values("date").reset_index(drop=True)

daily["ed_admission_share_daily_imputed"] = (
    daily["ed_admission_share_daily"]
    .interpolate(method="linear", limit_area="inside")
    .ffill()
    .bfill()
)

daily["total_ed_attendances_daily_imputed"] = (
    daily["total_ed_attendances_daily"]
    .interpolate(method="linear", limit_area="inside")
    .ffill()
    .bfill()
)

daily["ed_admission_pct_daily_imputed"] = (
    daily["ed_admission_share_daily_imputed"] * 100
)

daily["imputed_admission_share"] = ~daily["observed_admission_share"]
daily["imputed_total_attendances"] = ~daily["observed_total_attendances"]
daily["imputed_any_source"] = (
    daily["imputed_admission_share"] |
    daily["imputed_total_attendances"]
)

imputed_days = daily.loc[
    daily["imputed_any_source"],
    [
        "date",
        "ed_admission_share_daily",
        "ed_admission_share_daily_imputed",
        "total_ed_attendances_daily",
        "total_ed_attendances_daily_imputed",
        "imputed_admission_share",
        "imputed_total_attendances"
    ]
].copy()

imputed_days_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_imputed_daily_values.xlsx"
imputed_days.to_excel(imputed_days_path, index=False)

print("\n=== DAILY IMPUTATION CHECK ===")
print("Days imputed in at least one source:", len(imputed_days))
print(imputed_days.head(30))
print("Saved imputed-day audit to:", imputed_days_path)

remaining_missing_after = daily[
    daily[[
        "ed_admission_share_daily_imputed",
        "total_ed_attendances_daily_imputed"
    ]].isna().any(axis=1)
].copy()

if len(remaining_missing_after) > 0:
    remaining_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_remaining_missing_after_imputation.xlsx"
    remaining_missing_after.to_excel(remaining_path, index=False)
    raise ValueError(
        f"Missing values remain after imputation. Inspect: {remaining_path}"
    )

# ============================================================
# 6. Construct daily estimated admission-prone ED attendances
# ============================================================

daily["period"] = daily["date"].dt.to_period("M").dt.to_timestamp()
daily["year"] = daily["date"].dt.year
daily["month"] = daily["date"].dt.month

daily["admission_prone_ed_attendances_daily"] = (
    daily["ed_admission_share_daily_imputed"] *
    daily["total_ed_attendances_daily_imputed"]
)

# ============================================================
# 7. Raw and imputation checks
# ============================================================

print("\n=== RAW DATA CHECKS ===")
print("Date range:", daily["date"].min(), "to", daily["date"].max())
print("Expected number of days:", len(pd.date_range(START_DATE, END_DATE, freq="D")))
print("Rows in complete daily grid:", len(daily))
print("Observed admission-rate days:", daily["observed_admission_share"].sum())
print("Observed attendance days:", daily["observed_total_attendances"].sum())
print("Imputed admission-rate days:", daily["imputed_admission_share"].sum())
print("Imputed attendance days:", daily["imputed_total_attendances"].sum())

print("\nInterpretation:")
print("Variable 528 is treated as a daily admission share/rate, not as a cumulative count.")
print("The monthly indicator is computed as an attendance-weighted monthly share.")
print("Missing daily values are imputed before monthly aggregation to avoid underestimating monthly counts.")

# ============================================================
# 8. Monthly aggregation
# ============================================================

monthly = (
    daily.groupby("period", as_index=False)
    .agg(
        total_ed_attendances=("total_ed_attendances_daily_imputed", "sum"),
        admission_prone_ed_attendances=("admission_prone_ed_attendances_daily", "sum"),
        ed_admission_share_unweighted_mean=("ed_admission_share_daily_imputed", "mean"),
        ed_admission_share_median_daily=("ed_admission_share_daily_imputed", "median"),
        ed_admission_share_min_daily=("ed_admission_share_daily_imputed", "min"),
        ed_admission_share_max_daily=("ed_admission_share_daily_imputed", "max"),
        ed_admission_share_sd_daily=("ed_admission_share_daily_imputed", "std"),
        n_days_expected=("date", "nunique"),
        n_days_admission_share_observed=("observed_admission_share", "sum"),
        n_days_attendances_observed=("observed_total_attendances", "sum"),
        n_days_imputed_any_source=("imputed_any_source", "sum")
    )
)

monthly["region"] = REGION_NAME
monthly["days_in_month"] = monthly["period"].dt.days_in_month
monthly["complete_month_after_imputation"] = monthly["n_days_expected"] == monthly["days_in_month"]

monthly["year"] = monthly["period"].dt.year
monthly["month"] = monthly["period"].dt.month

monthly["ed_admission_share"] = (
    monthly["admission_prone_ed_attendances"] /
    monthly["total_ed_attendances"]
)

monthly["ed_admission_pct"] = monthly["ed_admission_share"] * 100

monthly["ed_admission_share_weighting_difference"] = (
    monthly["ed_admission_share"] -
    monthly["ed_admission_share_unweighted_mean"]
)

monthly["had_imputed_days"] = monthly["n_days_imputed_any_source"] > 0

monthly = monthly[
    [
        "period",
        "region",
        "ed_admission_share",
        "ed_admission_pct",
        "admission_prone_ed_attendances",
        "total_ed_attendances",
        "ed_admission_share_unweighted_mean",
        "ed_admission_share_weighting_difference",
        "ed_admission_share_median_daily",
        "ed_admission_share_min_daily",
        "ed_admission_share_max_daily",
        "ed_admission_share_sd_daily",
        "n_days_expected",
        "n_days_admission_share_observed",
        "n_days_attendances_observed",
        "n_days_imputed_any_source",
        "had_imputed_days",
        "days_in_month",
        "complete_month_after_imputation",
        "year",
        "month"
    ]
].sort_values("period").reset_index(drop=True)

# ============================================================
# 9. Monthly checks
# ============================================================

print("\n=== MONTHLY DATA PREVIEW ===")
print(monthly.head())
print(monthly.tail())

print("\n=== COVERAGE ===")
print(monthly["period"].min(), "to", monthly["period"].max())
print("Number of months:", len(monthly))
print("Months with imputed days:", monthly["had_imputed_days"].sum())
print(monthly.loc[monthly["had_imputed_days"], [
    "period",
    "n_days_imputed_any_source",
    "n_days_admission_share_observed",
    "n_days_attendances_observed",
    "days_in_month"
]])

print("\n=== MISSING VALUES IN FINAL MONTHLY DATASET ===")
print(monthly.isna().sum())

print("\n=== MAIN INDICATOR SUMMARY ===")
print(monthly[[
    "ed_admission_share",
    "ed_admission_pct",
    "admission_prone_ed_attendances",
    "total_ed_attendances"
]].describe())

# Internal consistency check
monthly["check_admission_share"] = (
    monthly["admission_prone_ed_attendances"] /
    monthly["total_ed_attendances"]
)

max_abs_diff = (
    monthly["check_admission_share"] -
    monthly["ed_admission_share"]
).abs().max()

print("\nInternal identity check:")
print("max |computed share - stored share| =", max_abs_diff)

monthly = monthly.drop(columns=["check_admission_share"])

if monthly["ed_admission_share"].isna().sum() > 0:
    raise ValueError("The final monthly ed_admission_share contains missing values.")

# ============================================================
# 10. Save clean files
# ============================================================

out_csv = CLEAN_DIR / f"{REGION_SLUG}_ed_admission_share_monthly.csv"
out_xlsx = CLEAN_DIR / f"{REGION_SLUG}_ed_admission_share_monthly.xlsx"

monthly.to_csv(out_csv, index=False)
monthly.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 11. Save imputed daily file for audit
# ============================================================

daily_audit_cols = [
    "date",
    "period",
    "ed_admission_share_daily",
    "ed_admission_share_daily_imputed",
    "total_ed_attendances_daily",
    "total_ed_attendances_daily_imputed",
    "admission_prone_ed_attendances_daily",
    "observed_admission_share",
    "observed_total_attendances",
    "imputed_admission_share",
    "imputed_total_attendances",
    "imputed_any_source",
    "year",
    "month"
]

daily_audit = daily[daily_audit_cols].copy()

daily_audit_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_daily_audit.xlsx"
daily_audit.to_excel(daily_audit_path, index=False)

print("Saved daily audit file:")
print(daily_audit_path)

# ============================================================
# 12. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["ed_admission_share"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Share of ED attendances admitted as inpatients")
plt.xlabel("Month")
plt.ylabel("ED admission share")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["ed_admission_share_weighting_difference"],
    marker="o",
    linewidth=1
)
plt.axhline(0, linewidth=1)
plt.title(f"{REGION_NAME} - Difference between weighted and unweighted monthly admission share")
plt.xlabel("Month")
plt.ylabel("Weighted share minus unweighted daily mean")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_weighting_difference.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["n_days_imputed_any_source"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Number of imputed daily observations by month")
plt.xlabel("Month")
plt.ylabel("Number of imputed days")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_ed_admission_share_imputed_days_by_month.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "alentejo"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "alentejo"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "alentejo" / "mean_waiting_time"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

file_path = RAW_DIR / "mean_wt.xlsx"

REGION_RAW = "ARS Alentejo"
REGION_NAME = "Região de Saúde do Alentejo"
REGION_SLUG = "alentejo"

INDICATOR_NAME = "Tempo médio de espera entre a triagem e a primeira observação médica (rede de urgência hospitalar)"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-31")

# ============================================================
# 1. Load raw data
# ============================================================

df = pd.read_excel(file_path)

df = df.rename(columns={
    "Período": "date",
    "Região/ARS": "region_raw",
    "Indicador": "indicator",
    "Valor": "mean_waiting_time_daily",
    "Unidade": "unit",
    "ID": "id"
})

df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["mean_waiting_time_daily"] = pd.to_numeric(
    df["mean_waiting_time_daily"],
    errors="coerce"
)

print("\n=== AVAILABLE REGIONS ===")
print(df["region_raw"].dropna().unique())

print("\n=== AVAILABLE INDICATORS ===")
print(df["indicator"].dropna().unique())

# ============================================================
# 2. Filter region, indicator, and study period
# ============================================================

df = df[
    (df["region_raw"] == REGION_RAW) &
    (df["indicator"] == INDICATOR_NAME) &
    (df["date"] >= START_DATE) &
    (df["date"] <= END_DATE)
].copy()

df = df.sort_values("date").reset_index(drop=True)

if len(df) == 0:
    raise ValueError(
        f"No rows found for region '{REGION_RAW}' and indicator '{INDICATOR_NAME}'. "
        "Check the file, region name, or indicator name."
    )

# If duplicates exist, average them safely.
df = (
    df.groupby("date", as_index=False)
      .agg(
          mean_waiting_time_daily=("mean_waiting_time_daily", "mean"),
          unit=("unit", lambda x: x.dropna().iloc[0] if len(x.dropna()) > 0 else np.nan)
      )
      .sort_values("date")
)

# ============================================================
# 3. Create complete daily grid and audit missing days
# ============================================================

daily = pd.DataFrame({
    "date": pd.date_range(START_DATE, END_DATE, freq="D")
})

daily = daily.merge(df, on="date", how="left")

daily["observed_waiting_time"] = daily["mean_waiting_time_daily"].notna()
daily["missing_waiting_time"] = daily["mean_waiting_time_daily"].isna()

missing_days = daily.loc[
    daily["missing_waiting_time"],
    ["date", "mean_waiting_time_daily", "observed_waiting_time"]
].copy()

missing_days_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_missing_daily_audit_before_imputation.xlsx"
missing_days.to_excel(missing_days_path, index=False)

print("\n=== DAILY MISSING CHECK BEFORE IMPUTATION ===")
print("Rows observed in raw filtered file:", len(df))
print("Complete daily grid rows:", len(daily))
print("Missing daily observations:", len(missing_days))
print(missing_days.head(30))
print("Saved missing-day audit to:", missing_days_path)

# ============================================================
# 4. Impute missing daily waiting time
# ============================================================

daily = daily.sort_values("date").reset_index(drop=True)

daily["mean_waiting_time_daily_imputed"] = (
    daily["mean_waiting_time_daily"]
    .interpolate(method="linear", limit_area="inside")
    .ffill()
    .bfill()
)

daily["imputed_waiting_time"] = ~daily["observed_waiting_time"]

imputed_days = daily.loc[
    daily["imputed_waiting_time"],
    [
        "date",
        "mean_waiting_time_daily",
        "mean_waiting_time_daily_imputed",
        "imputed_waiting_time"
    ]
].copy()

imputed_days_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_imputed_daily_values.xlsx"
imputed_days.to_excel(imputed_days_path, index=False)

print("\n=== DAILY IMPUTATION CHECK ===")
print("Days imputed:", len(imputed_days))
print(imputed_days.head(30))
print("Saved imputed-day audit to:", imputed_days_path)

remaining_missing_after = daily[
    daily["mean_waiting_time_daily_imputed"].isna()
].copy()

if len(remaining_missing_after) > 0:
    remaining_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_remaining_missing_after_imputation.xlsx"
    remaining_missing_after.to_excel(remaining_path, index=False)
    raise ValueError(
        f"Missing values remain after imputation. Inspect: {remaining_path}"
    )

# ============================================================
# 5. Add calendar variables
# ============================================================

daily["period"] = daily["date"].dt.to_period("M").dt.to_timestamp()
daily["year"] = daily["date"].dt.year
daily["month"] = daily["date"].dt.month
daily["weekday"] = daily["date"].dt.day_name()

# ============================================================
# 6. Raw checks
# ============================================================

print("\n=== RAW DATA CHECKS ===")
print("Date range:", daily["date"].min(), "to", daily["date"].max())
print("Expected number of days:", len(pd.date_range(START_DATE, END_DATE, freq="D")))
print("Rows in complete daily grid:", len(daily))
print("Observed waiting-time days:", daily["observed_waiting_time"].sum())
print("Imputed waiting-time days:", daily["imputed_waiting_time"].sum())
print("Unit:", df["unit"].dropna().unique())

print("\nInterpretation:")
print("Variable 405 is treated as a daily mean waiting time in minutes, not as a cumulative count.")
print("The monthly indicator is computed as the monthly mean of daily mean waiting times.")
print("Missing daily values are imputed before monthly aggregation so that the month is not based on a partial calendar.")

# ============================================================
# 7. Monthly aggregation
# ============================================================

monthly = (
    daily.groupby("period", as_index=False)
      .agg(
          mean_waiting_time_triage_to_first_obs=("mean_waiting_time_daily_imputed", "mean"),
          mean_waiting_time_median_daily=("mean_waiting_time_daily_imputed", "median"),
          mean_waiting_time_min_daily=("mean_waiting_time_daily_imputed", "min"),
          mean_waiting_time_max_daily=("mean_waiting_time_daily_imputed", "max"),
          mean_waiting_time_sd_daily=("mean_waiting_time_daily_imputed", "std"),
          mean_waiting_time_p90_daily=("mean_waiting_time_daily_imputed", lambda x: x.quantile(0.90)),
          n_days_expected=("date", "nunique"),
          n_days_observed=("observed_waiting_time", "sum"),
          n_days_imputed=("imputed_waiting_time", "sum")
      )
)

monthly["region"] = REGION_NAME
monthly["days_in_month"] = monthly["period"].dt.days_in_month
monthly["complete_month_after_imputation"] = monthly["n_days_expected"] == monthly["days_in_month"]
monthly["had_imputed_days"] = monthly["n_days_imputed"] > 0

monthly["year"] = monthly["period"].dt.year
monthly["month"] = monthly["period"].dt.month

monthly = monthly[
    [
        "period",
        "region",
        "mean_waiting_time_triage_to_first_obs",
        "mean_waiting_time_median_daily",
        "mean_waiting_time_min_daily",
        "mean_waiting_time_max_daily",
        "mean_waiting_time_sd_daily",
        "mean_waiting_time_p90_daily",
        "n_days_expected",
        "n_days_observed",
        "n_days_imputed",
        "had_imputed_days",
        "days_in_month",
        "complete_month_after_imputation",
        "year",
        "month"
    ]
].sort_values("period").reset_index(drop=True)

# ============================================================
# 8. Monthly checks
# ============================================================

print("\n=== MONTHLY DATA PREVIEW ===")
print(monthly.head())
print(monthly.tail())

print("\n=== COVERAGE ===")
print(monthly["period"].min(), "to", monthly["period"].max())
print("Number of months:", len(monthly))
print("Months with imputed days:", monthly["had_imputed_days"].sum())

print(monthly.loc[monthly["had_imputed_days"], [
    "period",
    "n_days_imputed",
    "n_days_observed",
    "days_in_month"
]])

print("\n=== MISSING VALUES IN FINAL MONTHLY DATASET ===")
print(monthly.isna().sum())

print("\n=== MAIN INDICATOR SUMMARY ===")
print(monthly[
    [
        "mean_waiting_time_triage_to_first_obs",
        "mean_waiting_time_median_daily",
        "mean_waiting_time_sd_daily",
        "n_days_observed",
        "n_days_imputed"
    ]
].describe())

if monthly["mean_waiting_time_triage_to_first_obs"].isna().sum() > 0:
    raise ValueError("The final monthly mean_waiting_time_triage_to_first_obs contains missing values.")

# ============================================================
# 9. Save clean files
# ============================================================

out_csv = CLEAN_DIR / f"{REGION_SLUG}_mean_waiting_time_monthly.csv"
out_xlsx = CLEAN_DIR / f"{REGION_SLUG}_mean_waiting_time_monthly.xlsx"

monthly.to_csv(out_csv, index=False)
monthly.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 10. Save daily audit
# ============================================================

daily_audit_cols = [
    "date",
    "period",
    "mean_waiting_time_daily",
    "mean_waiting_time_daily_imputed",
    "observed_waiting_time",
    "imputed_waiting_time",
    "year",
    "month",
    "weekday"
]

daily_audit = daily[daily_audit_cols].copy()

daily_audit_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_daily_audit.xlsx"
daily_audit.to_excel(daily_audit_path, index=False)

print("Saved daily audit file:")
print(daily_audit_path)

# ============================================================
# 11. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["mean_waiting_time_triage_to_first_obs"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Mean waiting time from triage to first medical observation")
plt.xlabel("Month")
plt.ylabel("Mean waiting time, minutes")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["mean_waiting_time_sd_daily"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Within-month daily variability in waiting time")
plt.xlabel("Month")
plt.ylabel("Standard deviation of daily mean waiting time, minutes")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_daily_variability.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["n_days_imputed"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Number of imputed daily waiting-time observations by month")
plt.xlabel("Month")
plt.ylabel("Number of imputed days")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_mean_waiting_time_imputed_days_by_month.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:", fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "alentejo"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "alentejo"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "alentejo" / "downstream_capacity"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

inpatient_file = RAW_DIR / "inpatient_activity.xlsx"

capacity_file = RAW_DIR / "operated_capacity.xlsx"
if not capacity_file.exists():
    capacity_file = RAW_DIR / "operated_bed_capacity.xlsx"

REGION_RAW = "Região de Saúde do Alentejo"
REGION_NAME = "Região de Saúde do Alentejo"
REGION_SLUG = "alentejo"

admission_file = CLEAN_DIR / f"{REGION_SLUG}_ed_admission_share_monthly.xlsx"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-01")

# ============================================================
# Helpers
# ============================================================

def parse_month_column(series):
    return pd.to_datetime(
        series.astype(str).str.slice(0, 7) + "-01",
        errors="coerce"
    )

def save_audit(df, path):
    df.to_excel(path, index=False)

# ============================================================
# 1. Load inpatient activity
# ============================================================

if not inpatient_file.exists():
    raise FileNotFoundError(f"Missing inpatient activity file: {inpatient_file}")

inp = pd.read_excel(inpatient_file)

inp = inp.rename(columns={
    "Período": "period",
    "Região": "region_raw",
    "Instituição": "institution",
    "Localização Geográfica": "geo",
    "Tipo de Especialidade": "specialty_type",
    "Doentes Saídos": "discharges_cum",
    "Dias de Internamento": "inpatient_days_cum"
})

required_inp_cols = [
    "period", "region_raw", "institution", "specialty_type",
    "discharges_cum", "inpatient_days_cum"
]

missing_inp_cols = [col for col in required_inp_cols if col not in inp.columns]
if missing_inp_cols:
    raise ValueError(
        f"Missing inpatient columns: {missing_inp_cols}. "
        f"Available: {inp.columns.tolist()}"
    )

inp["period"] = parse_month_column(inp["period"])
inp["discharges_cum"] = pd.to_numeric(inp["discharges_cum"], errors="coerce")
inp["inpatient_days_cum"] = pd.to_numeric(inp["inpatient_days_cum"], errors="coerce")

print("\n=== AVAILABLE REGIONS IN INPATIENT FILE ===")
print(inp["region_raw"].dropna().unique())

inp = inp[
    (inp["region_raw"] == REGION_RAW) &
    (inp["period"] >= START_DATE) &
    (inp["period"] <= END_DATE)
].copy()

if len(inp) == 0:
    raise ValueError(f"No inpatient rows found for {REGION_RAW}.")

inp = inp.sort_values(["institution", "specialty_type", "period"]).reset_index(drop=True)
inp["year"] = inp["period"].dt.year
inp["month"] = inp["period"].dt.month

print("\n=== INPATIENT ACTIVITY RAW CHECKS ===")
print("Rows:", len(inp))
print("Period:", inp["period"].min(), "to", inp["period"].max())
print("Institutions:", inp["institution"].nunique())
print("Specialty types:", inp["specialty_type"].dropna().unique())
print("Missing values:")
print(inp[["discharges_cum", "inpatient_days_cum"]].isna().sum())

# ============================================================
# 2. Treat missing cumulative inpatient values
# ============================================================

raw_missing_inp = inp.loc[
    inp[["discharges_cum", "inpatient_days_cum"]].isna().any(axis=1),
    ["period", "institution", "specialty_type", "discharges_cum", "inpatient_days_cum"]
].copy()

raw_missing_inp_path = EDA_DIR / f"{REGION_SLUG}_inpatient_activity_raw_missing_audit.xlsx"
save_audit(raw_missing_inp, raw_missing_inp_path)

inp_filled = inp.copy()
inpatient_missing_treatments = []

for (institution, specialty_type, year), idx in inp_filled.groupby(
    ["institution", "specialty_type", "year"],
    dropna=False
).groups.items():

    idx = list(idx)
    g = inp_filled.loc[idx].sort_values("period")

    for col in ["discharges_cum", "inpatient_days_cum"]:
        s = g[col].astype(float)
        n_missing_before = int(s.isna().sum())

        if s.isna().all():
            s_filled = pd.Series(0.0, index=g.index)
            treatment = "entire_institution_specialty_year_missing_set_to_zero"
        else:
            s_filled = s.interpolate(method="linear", limit_area="inside")
            s_filled = s_filled.ffill()
            s_filled = s_filled.fillna(0.0)
            treatment = "interpolate_internal_then_ffill_or_zero_leading"

        n_missing_after = int(s_filled.isna().sum())
        n_treated = n_missing_before - n_missing_after

        if n_missing_before > 0:
            inpatient_missing_treatments.append({
                "institution": institution,
                "specialty_type": specialty_type,
                "year": year,
                "variable": col,
                "treatment": treatment,
                "n_values_treated": n_treated if n_treated > 0 else len(g)
            })

        inp_filled.loc[g.index, col] = s_filled

inpatient_missing_treatments_df = pd.DataFrame(inpatient_missing_treatments)
inpatient_missing_treatments_path = EDA_DIR / f"{REGION_SLUG}_inpatient_activity_missing_treatment_audit.xlsx"
save_audit(inpatient_missing_treatments_df, inpatient_missing_treatments_path)

remaining_inp_missing = inp_filled.loc[
    inp_filled[["discharges_cum", "inpatient_days_cum"]].isna().any(axis=1),
    ["period", "institution", "specialty_type", "discharges_cum", "inpatient_days_cum"]
].copy()

remaining_inp_missing_path = EDA_DIR / f"{REGION_SLUG}_inpatient_activity_remaining_missing_after_treatment.xlsx"
save_audit(remaining_inp_missing, remaining_inp_missing_path)

print("\n=== INPATIENT MISSING TREATMENT ===")
print("Raw rows with missing values:", len(raw_missing_inp))
print("Treatment records:", len(inpatient_missing_treatments_df))
print("Rows still missing after treatment:", len(remaining_inp_missing))
print("Saved audits:")
print(raw_missing_inp_path)
print(inpatient_missing_treatments_path)
print(remaining_inp_missing_path)

# ============================================================
# 3. Cumulative behaviour audit
# ============================================================

audit_records = []

for (inst, spec, year), g in inp_filled.sort_values("period").groupby(
    ["institution", "specialty_type", "year"],
    dropna=False
):
    g = g.sort_values("period")

    for col in ["discharges_cum", "inpatient_days_cum"]:
        diff = g[col].diff()
        decreases = g.loc[
            diff < -1e-9,
            ["period", "institution", "specialty_type", col]
        ].copy()

        for _, row in decreases.iterrows():
            previous_rows = g.loc[g["period"] < row["period"], col]

            audit_records.append({
                "institution": inst,
                "specialty_type": spec,
                "year": year,
                "period": row["period"],
                "variable": col,
                "value": row[col],
                "previous_value": previous_rows.iloc[-1] if len(previous_rows) else np.nan,
                "decrease": row[col] - (previous_rows.iloc[-1] if len(previous_rows) else np.nan)
            })

institutional_audit = pd.DataFrame(audit_records)
institutional_audit_path = EDA_DIR / f"{REGION_SLUG}_inpatient_activity_institutional_cumulative_decreases.xlsx"
save_audit(institutional_audit, institutional_audit_path)

print("\nInstitution-level cumulative decreases:", len(institutional_audit))
print("Saved audit:", institutional_audit_path)

# ============================================================
# 4. Aggregate cumulative inpatient activity to region-specialty-month
# ============================================================

regional_spec_cum = (
    inp_filled
    .groupby(["period", "year", "specialty_type"], as_index=False)
    .agg(
        discharges_cum=("discharges_cum", "sum"),
        inpatient_days_cum=("inpatient_days_cum", "sum")
    )
    .sort_values(["specialty_type", "period"])
)

regional_decrease_checks = []

for (spec, year), g in regional_spec_cum.groupby(["specialty_type", "year"], dropna=False):
    g = g.sort_values("period")

    for col in ["discharges_cum", "inpatient_days_cum"]:
        n_decreases = int((g[col].diff() < -1e-9).sum())
        regional_decrease_checks.append({
            "specialty_type": spec,
            "year": year,
            "variable": col,
            "n_decreases": n_decreases
        })

regional_decrease_checks = pd.DataFrame(regional_decrease_checks)
regional_decrease_path = EDA_DIR / f"{REGION_SLUG}_inpatient_activity_regional_cumulative_check.xlsx"
save_audit(regional_decrease_checks, regional_decrease_path)

print("\nRegional cumulative decreases by variable:")
print(regional_decrease_checks.groupby("variable")["n_decreases"].sum())
print("Saved regional cumulative check:", regional_decrease_path)

# ============================================================
# 5. Convert cumulative inpatient activity to monthly flows
# ============================================================

regional_spec_monthly = regional_spec_cum.copy()
negative_inpatient_records = []

for cum_col, monthly_col in [
    ("discharges_cum", "inpatient_discharges"),
    ("inpatient_days_cum", "inpatient_days")
]:
    regional_spec_monthly[monthly_col] = (
        regional_spec_monthly
        .groupby(["specialty_type", "year"])[cum_col]
        .diff()
    )

    first_idx = regional_spec_monthly.groupby(["specialty_type", "year"]).head(1).index
    regional_spec_monthly.loc[first_idx, monthly_col] = regional_spec_monthly.loc[first_idx, cum_col]

    neg_mask = regional_spec_monthly[monthly_col] < -1e-9

    if neg_mask.any():
        for _, row in regional_spec_monthly.loc[neg_mask].iterrows():
            negative_inpatient_records.append({
                "period": row["period"],
                "specialty_type": row["specialty_type"],
                "year": row["year"],
                "variable": monthly_col,
                "raw_monthly_flow": row[monthly_col],
                "treatment": "negative_monthly_flow_clipped_to_zero"
            })

        regional_spec_monthly.loc[neg_mask, monthly_col] = 0.0

negative_inpatient = pd.DataFrame(negative_inpatient_records)
negative_path = EDA_DIR / f"{REGION_SLUG}_inpatient_activity_negative_monthly_flows.xlsx"
save_audit(negative_inpatient, negative_path)

print("\nNegative monthly inpatient flows clipped to zero:", len(negative_inpatient))
print("Saved:", negative_path)

# ============================================================
# 6. Standardise specialty names and pivot inpatient activity
# ============================================================

specialty_map = {
    "Especialidade Cirurgica": "surgical",
    "Especialidade Cirúrgica": "surgical",
    "Especialidade Médica": "medical",
    "Outras Camas": "other"
}

regional_spec_monthly["specialty_group"] = (
    regional_spec_monthly["specialty_type"]
    .map(specialty_map)
    .fillna(
        regional_spec_monthly["specialty_type"]
        .astype(str)
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace("/", "_", regex=False)
    )
)

inpatient_days_by_type = (
    regional_spec_monthly
    .pivot_table(
        index="period",
        columns="specialty_group",
        values="inpatient_days",
        aggfunc="sum"
    )
    .reset_index()
)

discharges_by_type = (
    regional_spec_monthly
    .pivot_table(
        index="period",
        columns="specialty_group",
        values="inpatient_discharges",
        aggfunc="sum"
    )
    .reset_index()
)

for col in ["medical", "surgical", "other"]:
    if col not in inpatient_days_by_type.columns:
        inpatient_days_by_type[col] = 0.0
    if col not in discharges_by_type.columns:
        discharges_by_type[col] = 0.0

inpatient_days_by_type = inpatient_days_by_type.rename(columns={
    "medical": "inpatient_days_medical",
    "surgical": "inpatient_days_surgical",
    "other": "inpatient_days_other"
})

discharges_by_type = discharges_by_type.rename(columns={
    "medical": "inpatient_discharges_medical",
    "surgical": "inpatient_discharges_surgical",
    "other": "inpatient_discharges_other"
})

inpatient_monthly = inpatient_days_by_type.merge(
    discharges_by_type,
    on="period",
    how="outer"
)

inpatient_day_cols = [
    col for col in inpatient_monthly.columns
    if col.startswith("inpatient_days_")
]

discharge_cols = [
    col for col in inpatient_monthly.columns
    if col.startswith("inpatient_discharges_")
]

inpatient_monthly["inpatient_days"] = inpatient_monthly[inpatient_day_cols].sum(axis=1)
inpatient_monthly["inpatient_discharges"] = inpatient_monthly[discharge_cols].sum(axis=1)

# ============================================================
# 7. Load operated bed capacity
# ============================================================

if not capacity_file.exists():
    raise FileNotFoundError(f"Missing operated capacity file: {capacity_file}")

cap = pd.read_excel(capacity_file)

cap = cap.rename(columns={
    "Período": "period",
    "Região": "region_raw",
    "Instituição": "institution",
    "Localização Geográfica": "geo",
    "Tipo de Camas": "bed_type",
    "Lotação": "operated_beds"
})

required_cap_cols = ["period", "region_raw", "institution", "bed_type", "operated_beds"]
missing_cap_cols = [col for col in required_cap_cols if col not in cap.columns]

if missing_cap_cols:
    raise ValueError(
        f"Missing capacity columns: {missing_cap_cols}. "
        f"Available: {cap.columns.tolist()}"
    )

cap["period"] = parse_month_column(cap["period"])
cap["operated_beds"] = pd.to_numeric(cap["operated_beds"], errors="coerce")

print("\n=== AVAILABLE REGIONS IN CAPACITY FILE ===")
print(cap["region_raw"].dropna().unique())

cap = cap[
    (cap["region_raw"] == REGION_RAW) &
    (cap["period"] >= START_DATE) &
    (cap["period"] <= END_DATE)
].copy()

if len(cap) == 0:
    raise ValueError(f"No capacity rows found for {REGION_RAW}.")

cap = cap.sort_values(["institution", "bed_type", "period"]).reset_index(drop=True)
cap["year"] = cap["period"].dt.year
cap["month"] = cap["period"].dt.month

print("\n=== OPERATED BED CAPACITY RAW CHECKS ===")
print("Rows:", len(cap))
print("Period:", cap["period"].min(), "to", cap["period"].max())
print("Institutions:", cap["institution"].nunique())
print("Bed types:", cap["bed_type"].dropna().unique())
print("Missing operated_beds:", cap["operated_beds"].isna().sum())

raw_missing_cap = cap.loc[
    cap["operated_beds"].isna(),
    ["period", "institution", "bed_type", "operated_beds"]
].copy()

raw_missing_cap_path = EDA_DIR / f"{REGION_SLUG}_operated_bed_capacity_raw_missing_audit.xlsx"
save_audit(raw_missing_cap, raw_missing_cap_path)

# ============================================================
# 8. Treat missing operated bed capacity values
# ============================================================

cap_filled = cap.copy()
capacity_missing_treatments = []

for (institution, bed_type), idx in cap_filled.groupby(["institution", "bed_type"], dropna=False).groups.items():
    idx = list(idx)
    g = cap_filled.loc[idx].sort_values("period")
    s = g["operated_beds"].astype(float)

    n_missing_before = int(s.isna().sum())

    if s.isna().all():
        s_filled = pd.Series(0.0, index=g.index)
        treatment = "entire_institution_bed_type_missing_set_to_zero"
    else:
        s_filled = s.interpolate(method="linear", limit_area="inside")
        s_filled = s_filled.ffill()
        s_filled = s_filled.bfill()
        treatment = "interpolate_internal_then_ffill_bfill"

    n_missing_after = int(s_filled.isna().sum())
    n_treated = n_missing_before - n_missing_after

    if n_missing_before > 0:
        capacity_missing_treatments.append({
            "institution": institution,
            "bed_type": bed_type,
            "treatment": treatment,
            "n_values_treated": n_treated if n_treated > 0 else len(g)
        })

    cap_filled.loc[g.index, "operated_beds"] = s_filled

capacity_missing_treatments_df = pd.DataFrame(capacity_missing_treatments)
capacity_missing_treatments_path = EDA_DIR / f"{REGION_SLUG}_operated_bed_capacity_missing_treatment_audit.xlsx"
save_audit(capacity_missing_treatments_df, capacity_missing_treatments_path)

remaining_cap_missing = cap_filled.loc[
    cap_filled["operated_beds"].isna(),
    ["period", "institution", "bed_type", "operated_beds"]
].copy()

remaining_cap_missing_path = EDA_DIR / f"{REGION_SLUG}_operated_bed_capacity_remaining_missing_after_treatment.xlsx"
save_audit(remaining_cap_missing, remaining_cap_missing_path)

print("\n=== CAPACITY MISSING TREATMENT ===")
print("Raw missing capacity rows:", len(raw_missing_cap))
print("Treatment records:", len(capacity_missing_treatments_df))
print("Rows still missing after treatment:", len(remaining_cap_missing))
print("Saved audits:")
print(raw_missing_cap_path)
print(capacity_missing_treatments_path)
print(remaining_cap_missing_path)

# ============================================================
# 9. Aggregate capacity by bed type
# ============================================================

bed_type_map = {
    "Camas Cirúrgicas": "surgical",
    "Camas Cirurgicas": "surgical",
    "Camas Médicas": "medical",
    "Camas Medicas": "medical",
    "Camas Neutras": "neutral",
    "Outras Camas": "other"
}

cap_filled["bed_group"] = (
    cap_filled["bed_type"]
    .map(bed_type_map)
    .fillna(
        cap_filled["bed_type"]
        .astype(str)
        .str.lower()
        .str.replace(" ", "_", regex=False)
        .str.replace("/", "_", regex=False)
    )
)

capacity_by_type = (
    cap_filled
    .pivot_table(
        index="period",
        columns="bed_group",
        values="operated_beds",
        aggfunc="sum"
    )
    .reset_index()
)

for col in ["medical", "surgical", "neutral", "other"]:
    if col not in capacity_by_type.columns:
        capacity_by_type[col] = 0.0

capacity_by_type = capacity_by_type.rename(columns={
    "medical": "operated_beds_medical",
    "surgical": "operated_beds_surgical",
    "neutral": "operated_beds_neutral",
    "other": "operated_beds_other"
})

capacity_cols = [
    "operated_beds_medical",
    "operated_beds_surgical",
    "operated_beds_neutral",
    "operated_beds_other"
]

capacity_by_type["operated_acute_beds"] = capacity_by_type[capacity_cols].sum(axis=1)

capacity_by_type = capacity_by_type.sort_values("period").reset_index(drop=True)

capacity_by_type["capacity_mom_change_pct"] = (
    capacity_by_type["operated_acute_beds"].pct_change() * 100
)

large_capacity_changes = capacity_by_type.loc[
    capacity_by_type["capacity_mom_change_pct"].abs() > 10,
    ["period", "operated_acute_beds", "capacity_mom_change_pct"] + capacity_cols
].copy()

large_capacity_changes_path = EDA_DIR / f"{REGION_SLUG}_operated_bed_capacity_large_monthly_changes.xlsx"
save_audit(large_capacity_changes, large_capacity_changes_path)

print("\nLarge operated capacity month-on-month changes >10%:", len(large_capacity_changes))
print("Saved:", large_capacity_changes_path)

# ============================================================
# 10. Compute inpatient bed occupancy rate
# ============================================================

downstream = inpatient_monthly.merge(
    capacity_by_type,
    on="period",
    how="outer"
)

downstream["region"] = REGION_NAME
downstream["days_in_month"] = downstream["period"].dt.days_in_month

downstream["inpatient_bed_occupancy_rate"] = (
    downstream["inpatient_days"] /
    (downstream["operated_acute_beds"] * downstream["days_in_month"])
)

downstream["inpatient_bed_occupancy_pct"] = (
    downstream["inpatient_bed_occupancy_rate"] * 100
)

# ============================================================
# 11. Load admission-prone ED attendances
# ============================================================

if not admission_file.exists():
    raise FileNotFoundError(
        f"Missing file: {admission_file}. "
        "Run the Alentejo ed_admission_share script first."
    )

adm = pd.read_excel(admission_file)
adm["period"] = parse_month_column(adm["period"])

needed_adm_cols = [
    "period",
    "admission_prone_ed_attendances",
    "ed_admission_share",
    "total_ed_attendances"
]

missing_cols = [col for col in needed_adm_cols if col not in adm.columns]

if missing_cols:
    raise ValueError(f"The admission file is missing required columns: {missing_cols}")

adm = adm[needed_adm_cols].copy()

downstream = downstream.merge(
    adm,
    on="period",
    how="left"
)

# ============================================================
# 12. Compute admission-prone ED load per operated acute bed
# ============================================================

downstream["admission_prone_ed_load_per_bed"] = (
    downstream["admission_prone_ed_attendances"] /
    downstream["operated_acute_beds"]
)

# ============================================================
# 13. Complete expected monthly grid and final dataset
# ============================================================

expected_months = pd.DataFrame({
    "period": pd.date_range(START_DATE, END_DATE, freq="MS")
})

downstream = expected_months.merge(
    downstream,
    on="period",
    how="left"
)

downstream["region"] = downstream["region"].fillna(REGION_NAME)
downstream["days_in_month"] = downstream["period"].dt.days_in_month
downstream["year"] = downstream["period"].dt.year
downstream["month"] = downstream["period"].dt.month

final_cols = [
    "period",
    "region",

    # Indicators for the pressure index
    "inpatient_bed_occupancy_rate",
    "admission_prone_ed_load_per_bed",

    # Readable versions / direct components
    "inpatient_bed_occupancy_pct",
    "inpatient_days",
    "operated_acute_beds",
    "days_in_month",
    "admission_prone_ed_attendances",
    "ed_admission_share",
    "total_ed_attendances",

    # Audit: inpatient activity by specialty
    "inpatient_days_medical",
    "inpatient_days_surgical",
    "inpatient_days_other",
    "inpatient_discharges",
    "inpatient_discharges_medical",
    "inpatient_discharges_surgical",
    "inpatient_discharges_other",

    # Audit: capacity by bed type
    "operated_beds_medical",
    "operated_beds_surgical",
    "operated_beds_neutral",
    "operated_beds_other",

    "year",
    "month"
]

for col in final_cols:
    if col not in downstream.columns:
        downstream[col] = np.nan

downstream_final = (
    downstream[final_cols]
    .sort_values("period")
    .reset_index(drop=True)
)

# ============================================================
# 14. Final checks
# ============================================================

print("\n=== FINAL DOWNSTREAM DATASET CHECKS ===")
print("Period:", downstream_final["period"].min(), "to", downstream_final["period"].max())
print("Number of months:", len(downstream_final))

print("\nMissing values in main variables:")
print(downstream_final[
    [
        "inpatient_bed_occupancy_rate",
        "admission_prone_ed_load_per_bed",
        "inpatient_days",
        "operated_acute_beds",
        "admission_prone_ed_attendances"
    ]
].isna().sum())

print("\nInpatient bed occupancy rate summary:")
print(downstream_final["inpatient_bed_occupancy_rate"].describe())

print("\nAdmission-prone ED load per bed summary:")
print(downstream_final["admission_prone_ed_load_per_bed"].describe())

print("\nHighest occupancy months:")
print(
    downstream_final
    .sort_values("inpatient_bed_occupancy_rate", ascending=False)
    [["period", "inpatient_bed_occupancy_rate", "inpatient_days", "operated_acute_beds"]]
    .head(10)
)

print("\nLowest occupancy months:")
print(
    downstream_final
    .sort_values("inpatient_bed_occupancy_rate")
    [["period", "inpatient_bed_occupancy_rate", "inpatient_days", "operated_acute_beds"]]
    .head(10)
)

downstream_final["check_occupancy"] = (
    downstream_final["inpatient_days"] /
    (downstream_final["operated_acute_beds"] * downstream_final["days_in_month"])
)

downstream_final["check_load_per_bed"] = (
    downstream_final["admission_prone_ed_attendances"] /
    downstream_final["operated_acute_beds"]
)

print("\nInternal identity checks:")
print(
    "max |occupancy - check| =",
    (downstream_final["inpatient_bed_occupancy_rate"] - downstream_final["check_occupancy"]).abs().max()
)
print(
    "max |load per bed - check| =",
    (downstream_final["admission_prone_ed_load_per_bed"] - downstream_final["check_load_per_bed"]).abs().max()
)

downstream_final = downstream_final.drop(columns=["check_occupancy", "check_load_per_bed"])

if downstream_final[["inpatient_bed_occupancy_rate", "admission_prone_ed_load_per_bed"]].isna().any().any():
    missing_final_path = EDA_DIR / f"{REGION_SLUG}_downstream_final_missing_main_indicators.xlsx"
    downstream_final.loc[
        downstream_final[["inpatient_bed_occupancy_rate", "admission_prone_ed_load_per_bed"]].isna().any(axis=1)
    ].to_excel(missing_final_path, index=False)

    raise ValueError(
        f"Missing values remain in downstream index indicators. Inspect: {missing_final_path}"
    )

# ============================================================
# 15. Save files
# ============================================================

out_csv = CLEAN_DIR / f"{REGION_SLUG}_downstream_capacity_monthly.csv"
out_xlsx = CLEAN_DIR / f"{REGION_SLUG}_downstream_capacity_monthly.xlsx"

downstream_final.to_csv(out_csv, index=False)
downstream_final.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 16. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    downstream_final["period"],
    downstream_final["inpatient_bed_occupancy_rate"],
    marker="o",
    linewidth=1
)
plt.axhline(1.0, linewidth=1)
plt.title(f"{REGION_NAME} - Inpatient bed occupancy rate")
plt.xlabel("Month")
plt.ylabel("Occupancy rate")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_inpatient_bed_occupancy_rate_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure:", fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    downstream_final["period"],
    downstream_final["admission_prone_ed_load_per_bed"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Admission-prone ED load per operated acute bed")
plt.xlabel("Month")
plt.ylabel("Admission-prone ED attendances per operated acute bed")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_admission_prone_ed_load_per_bed_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure:", fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    downstream_final["period"],
    downstream_final["operated_acute_beds"],
    marker="o",
    linewidth=1
)
plt.title(f"{REGION_NAME} - Operated acute bed capacity")
plt.xlabel("Month")
plt.ylabel("Operated acute beds")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / f"{REGION_SLUG}_operated_acute_beds_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure:", fig_path)

from pathlib import Path
import pandas as pd

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "alentejo"
CLEAN_DIR = BASE_DIR / "clean"

OUT_FILE_XLSX = CLEAN_DIR / "alentejo_pressure_index_indicators_monthly.xlsx"
OUT_FILE_CSV = CLEAN_DIR / "alentejo_pressure_index_indicators_monthly.csv"

REGION_NAME = "Região de Saúde do Alentejo"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-01")

# ============================================================
# Helper function
# ============================================================

def load_indicator(file_name, indicator_cols):
    path = CLEAN_DIR / file_name

    if not path.exists():
        raise FileNotFoundError(f"Missing file: {path}")

    df = pd.read_excel(path)
    df["period"] = pd.to_datetime(df["period"], errors="coerce")

    required_cols = ["period"] + indicator_cols
    missing_cols = [col for col in required_cols if col not in df.columns]

    if missing_cols:
        raise ValueError(
            f"File {file_name} is missing columns: {missing_cols}\n"
            f"Available columns: {df.columns.tolist()}"
        )

    df = df[required_cols].copy()

    df = df[
        (df["period"] >= START_DATE) &
        (df["period"] <= END_DATE)
    ].copy()

    if df.duplicated(subset=["period"]).any():
        dup = df[df.duplicated(subset=["period"], keep=False)]
        raise ValueError(
            f"Duplicated period rows found in {file_name}:\n{dup}"
        )

    return df.sort_values("period").reset_index(drop=True)

# ============================================================
# 1. Load required indicator columns
# ============================================================

total_ed = load_indicator(
    "alentejo_total_ed_attendances_monthly.xlsx",
    ["total_ed_attendances"]
)

high_acuity = load_indicator(
    "alentejo_high_acuity_manchester_share_monthly.xlsx",
    ["high_acuity_manchester_share"]
)

admission_share = load_indicator(
    "alentejo_ed_admission_share_monthly.xlsx",
    ["ed_admission_share"]
)

waiting_time = load_indicator(
    "alentejo_mean_waiting_time_monthly.xlsx",
    ["mean_waiting_time_triage_to_first_obs"]
)

downstream = load_indicator(
    "alentejo_downstream_capacity_monthly.xlsx",
    [
        "inpatient_bed_occupancy_rate",
        "admission_prone_ed_load_per_bed"
    ]
)

# ============================================================
# 2. Merge all indicators by period only
# ============================================================

dfs = [
    total_ed,
    high_acuity,
    admission_share,
    waiting_time,
    downstream
]

panel = dfs[0]

for df in dfs[1:]:
    panel = panel.merge(
        df,
        on="period",
        how="outer",
        validate="one_to_one"
    )

# ============================================================
# 3. Add standardised region and order columns
# ============================================================

panel = panel[
    (panel["period"] >= START_DATE) &
    (panel["period"] <= END_DATE)
].copy()

panel["region"] = REGION_NAME

indicator_cols = [
    "total_ed_attendances",
    "high_acuity_manchester_share",
    "ed_admission_share",
    "mean_waiting_time_triage_to_first_obs",
    "inpatient_bed_occupancy_rate",
    "admission_prone_ed_load_per_bed"
]

panel = panel[
    ["period", "region"] + indicator_cols
].sort_values("period").reset_index(drop=True)

# ============================================================
# 4. Checks
# ============================================================

print("\n=== FINAL PRESSURE INDICATOR PANEL - ALENTEJO ===")
print(panel.head())
print(panel.tail())

print("\nCoverage:")
print(panel["period"].min(), "to", panel["period"].max())
print("Number of months:", len(panel))

print("\nMissing values by column:")
print(panel.isna().sum())

print("\nDuplicated period-region rows:")
print(panel.duplicated(subset=["period", "region"]).sum())

print("\nDescriptive statistics:")
print(panel[indicator_cols].describe())

expected_months = pd.date_range(START_DATE, END_DATE, freq="MS")
missing_months = sorted(set(expected_months) - set(panel["period"]))

print("\nMissing months:")
print(missing_months if missing_months else "No missing months.")

if len(panel) != len(expected_months):
    print("\nWARNING: Number of months differs from expected.")
else:
    print("\nMonth count is correct.")

if panel[indicator_cols].isna().sum().sum() > 0:
    print("\nWARNING: Missing indicator values detected.")
    print(panel.loc[
        panel[indicator_cols].isna().any(axis=1),
        ["period", "region"] + indicator_cols
    ])
else:
    print("\nNo missing indicator values detected.")

# ============================================================
# 5. Save final clean indicator panel
# ============================================================

panel.to_excel(OUT_FILE_XLSX, index=False)
panel.to_csv(OUT_FILE_CSV, index=False)

print("\nSaved files:")
print(OUT_FILE_XLSX)
print(OUT_FILE_CSV)