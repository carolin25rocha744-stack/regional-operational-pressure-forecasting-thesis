from pathlib import Path
import os
ROOT = Path(__file__).resolve().parents[2]
import matplotlib
matplotlib.use("Agg")
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "norte"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "norte"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "norte" / "total_attendances"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

file_path = RAW_DIR / "total_attendences.xlsx"

REGION_RAW = "ARS Norte"
REGION_NAME = "Região de Saúde Norte"
INDICATOR_NAME = "Número estimado de episódios de urgência"

START_DATE = "2017-01-01"
END_DATE = "2025-12-31"

# ============================================================
# 1. Load data
# ============================================================

df = pd.read_excel(file_path)

df = df.rename(columns={
    "Período": "date",
    "Região/ARS": "region_raw",
    "Indicador": "indicator",
    "Valor": "value",
    "Unidade": "unit",
    "ID": "id"
})

df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["value"] = pd.to_numeric(df["value"], errors="coerce")

# ============================================================
# 2. Filter indicator, region, and study period
# ============================================================

df = df[
    (df["region_raw"] == REGION_RAW) &
    (df["indicator"] == INDICATOR_NAME) &
    (df["date"] >= START_DATE) &
    (df["date"] <= END_DATE)
].copy()

df = df.sort_values("date")

# Optional safety check: one row per day expected
duplicates = df.duplicated(subset=["date", "region_raw", "indicator"]).sum()
print(f"Duplicate daily records: {duplicates}")

# ============================================================
# 3. Aggregate daily emergency attendances to monthly totals
# ============================================================

df["period"] = df["date"].dt.to_period("M").dt.to_timestamp()

monthly = (
    df.groupby("period", as_index=False)
      .agg(
          total_ed_attendances=("value", "sum"),
          n_days_reported=("date", "nunique")
      )
)

monthly["region"] = REGION_NAME
monthly["days_in_month"] = monthly["period"].dt.days_in_month
monthly["complete_month"] = monthly["n_days_reported"] == monthly["days_in_month"]

monthly["year"] = monthly["period"].dt.year
monthly["month"] = monthly["period"].dt.month

monthly = monthly[
    [
        "period",
        "region",
        "total_ed_attendances",
        "n_days_reported",
        "days_in_month",
        "complete_month",
        "year",
        "month"
    ]
].sort_values("period")

# ============================================================
# 4. Basic checks
# ============================================================

print("\nMonthly dataset:")
print(monthly.head())
print(monthly.tail())

print("\nCoverage:")
print(monthly["period"].min(), "to", monthly["period"].max())
print("Number of months:", len(monthly))
print("Incomplete months:", (~monthly["complete_month"]).sum())

# ============================================================
# 5. Save clean files
# ============================================================

out_csv = CLEAN_DIR / "norte_total_ed_attendances_monthly.csv"
out_xlsx = CLEAN_DIR / "norte_total_ed_attendances_monthly.xlsx"

monthly.to_csv(out_csv, index=False)
monthly.to_excel(out_xlsx, index=False)

print("\nSaved files to:")
print(out_csv)
print(out_xlsx)

# ============================================================
# 6. EDA plot
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["total_ed_attendances"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Total emergency department attendances")
plt.xlabel("Month")
plt.ylabel("Monthly ED attendances")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_total_ed_attendances_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "norte"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "norte"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "norte" / "high_acuity"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

# Ajusta se o nome do ficheiro for diferente
file_path = RAW_DIR / "data 7 final" / "high_acuity.xlsx"

if not file_path.exists():
    file_path = RAW_DIR / "high_acuity.xlsx"

REGION_RAW = "Região de Saúde Norte"
REGION_NAME = "Região de Saúde Norte"

START_DATE = "2017-01-01"
END_DATE = "2025-12-01"

# ============================================================
# 1. Load data
# ============================================================

df = pd.read_excel(file_path)

df = df.rename(columns={
    "Período": "period",
    "Região": "region_raw",
    "Instituição": "institution",
    "Localização Geográfica": "geo",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Vermelha": "red_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Laranja": "orange_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Amarela": "yellow_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Verde": "green_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Azul": "blue_cum",
    "Nº Atendimentos em Urgência SU Triagem Manchester -Branca": "white_cum",
    "Nº Atendimentos s\\ Triagem Manchester": "no_triage_cum"
})

# Period is monthly, e.g. "2017-01"
df["period"] = pd.to_datetime(df["period"].astype(str) + "-01", errors="coerce")

count_cum_cols = [
    "red_cum",
    "orange_cum",
    "yellow_cum",
    "green_cum",
    "blue_cum",
    "white_cum",
    "no_triage_cum"
]

for col in count_cum_cols:
    df[col] = pd.to_numeric(df[col], errors="coerce")

# ============================================================
# 2. Filter region and study period
# ============================================================

df = df[
    (df["region_raw"] == REGION_RAW) &
    (df["period"] >= START_DATE) &
    (df["period"] <= END_DATE)
].copy()

df = df.sort_values(["institution", "period"])
df["year"] = df["period"].dt.year
df["month"] = df["period"].dt.month

print("Loaded rows:", len(df))
print("Institutions:", df["institution"].nunique())
print("Period:", df["period"].min(), "to", df["period"].max())

# ============================================================
# 3. Missing-value handling before cumulative reconstruction
# ============================================================

# If all count columns are missing in a row, this is treated as a missing institutional report.
# If only some columns are missing, they are treated as zero for that category.
df["all_counts_missing"] = df[count_cum_cols].isna().all(axis=1)

print("\nRows with all count columns missing:")
print(df.loc[df["all_counts_missing"], ["period", "institution"]])

for col in count_cum_cols:
    mask_partial_missing = (~df["all_counts_missing"]) & (df[col].isna())
    df.loc[mask_partial_missing, col] = 0

# For isolated fully missing cumulative rows, interpolate within institution-year.
# This avoids creating artificial regional drops in cumulative totals.
df_interp = df.copy()

for col in count_cum_cols:
    df_interp[col] = (
        df_interp
        .groupby(["institution", "year"], group_keys=False)[col]
        .apply(lambda s: s.interpolate(method="linear", limit_area="inside"))
    )

# Save rows that still have missing values after interpolation
remaining_missing = df_interp[df_interp[count_cum_cols].isna().any(axis=1)].copy()

if len(remaining_missing) > 0:
    missing_path = EDA_DIR / "norte_manchester_remaining_missing_after_interpolation.xlsx"
    remaining_missing.to_excel(missing_path, index=False)
    print("\nWARNING: Some missing cumulative values remain after interpolation.")
    print("Saved to:", missing_path)

# ============================================================
# 4. Check cumulative behaviour at institutional level
# ============================================================

audit_records = []

for (institution, year), g in df_interp.groupby(["institution", "year"]):
    g = g.sort_values("period")
    for col in count_cum_cols:
        diff = g[col].diff()
        decreases = g.loc[diff < -1e-9, ["period", "institution", col]].copy()

        for _, row in decreases.iterrows():
            audit_records.append({
                "institution": institution,
                "year": year,
                "period": row["period"],
                "variable": col,
                "value": row[col],
                "previous_value": g.loc[g["period"] < row["period"], col].iloc[-1]
            })

audit = pd.DataFrame(audit_records)

audit_path = EDA_DIR / "norte_manchester_cumulative_decrease_audit.xlsx"
audit.to_excel(audit_path, index=False)

print("\nInstitution-year cumulative decreases found:", len(audit))
print("Saved cumulative audit to:", audit_path)

# ============================================================
# 5. Aggregate cumulative values to regional level
# ============================================================

# Important:
# Because some institutions change designation over time,
# we aggregate cumulative values to region-month first and then difference by year.
# This avoids overcounting the first month after an institutional name change.

regional_cum = (
    df_interp
    .groupby(["period", "year"], as_index=False)[count_cum_cols]
    .sum(min_count=1)
    .sort_values("period")
)

regional_cum["region"] = REGION_NAME

# ============================================================
# 6. Convert regional cumulative counts into true monthly counts
# ============================================================

monthly = regional_cum.copy()

monthly_count_cols = {
    "red_cum": "red_manchester_attendances",
    "orange_cum": "orange_manchester_attendances",
    "yellow_cum": "yellow_manchester_attendances",
    "green_cum": "green_manchester_attendances",
    "blue_cum": "blue_manchester_attendances",
    "white_cum": "white_manchester_attendances",
    "no_triage_cum": "no_manchester_triage_attendances"
}

for cum_col, monthly_col in monthly_count_cols.items():
    monthly[monthly_col] = monthly.groupby("year")[cum_col].diff()

    # January should start from zero again; the first month of each year equals its cumulative value.
    first_idx = monthly.groupby("year").head(1).index
    monthly.loc[first_idx, monthly_col] = monthly.loc[first_idx, cum_col]

monthly_cols = list(monthly_count_cols.values())

# Check negative monthly counts after reconstruction
negative_monthly = monthly[
    (monthly[monthly_cols] < -1e-9).any(axis=1)
].copy()

if len(negative_monthly) > 0:
    negative_path = EDA_DIR / "norte_manchester_negative_monthly_counts.xlsx"
    negative_monthly.to_excel(negative_path, index=False)
    print("\nWARNING: Negative monthly counts detected after differencing.")
    print("Saved to:", negative_path)

# ============================================================
# 7. Construct high-acuity Manchester share
# ============================================================

# Known Manchester-coded attendances exclude "no triage".
# White is kept in the known Manchester-coded denominator, because it is a reported triage category.
known_cols = [
    "red_manchester_attendances",
    "orange_manchester_attendances",
    "yellow_manchester_attendances",
    "green_manchester_attendances",
    "blue_manchester_attendances",
    "white_manchester_attendances"
]

monthly["known_manchester_attendances"] = monthly[known_cols].sum(axis=1)

monthly["high_acuity_manchester_attendances"] = (
    monthly["red_manchester_attendances"] +
    monthly["orange_manchester_attendances"]
)

monthly["high_acuity_manchester_share"] = (
    monthly["high_acuity_manchester_attendances"] /
    monthly["known_manchester_attendances"]
)

monthly["total_with_or_without_manchester_triage"] = (
    monthly["known_manchester_attendances"] +
    monthly["no_manchester_triage_attendances"]
)

monthly["manchester_triage_coverage_share"] = (
    monthly["known_manchester_attendances"] /
    monthly["total_with_or_without_manchester_triage"]
)

# ============================================================
# 8. Final monthly dataset
# ============================================================

monthly["month"] = monthly["period"].dt.month

final_cols = [
    "period",
    "region",
    "red_manchester_attendances",
    "orange_manchester_attendances",
    "yellow_manchester_attendances",
    "green_manchester_attendances",
    "blue_manchester_attendances",
    "white_manchester_attendances",
    "no_manchester_triage_attendances",
    "known_manchester_attendances",
    "high_acuity_manchester_attendances",
    "high_acuity_manchester_share",
    "manchester_triage_coverage_share",
    "year",
    "month"
]

monthly_final = monthly[final_cols].sort_values("period").copy()

print("\nFinal monthly dataset:")
print(monthly_final.head())
print(monthly_final.tail())

print("\nCoverage:")
print(monthly_final["period"].min(), "to", monthly_final["period"].max())
print("Number of months:", len(monthly_final))

print("\nHigh-acuity Manchester share summary:")
print(monthly_final["high_acuity_manchester_share"].describe())

# ============================================================
# 9. Save clean files
# ============================================================

out_csv = CLEAN_DIR / "norte_high_acuity_manchester_share_monthly.csv"
out_xlsx = CLEAN_DIR / "norte_high_acuity_manchester_share_monthly.xlsx"

monthly_final.to_csv(out_csv, index=False)
monthly_final.to_excel(out_xlsx, index=False)

print("\nSaved files to:")
print(out_csv)
print(out_xlsx)

# ============================================================
# 10. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly_final["period"],
    monthly_final["high_acuity_manchester_share"],
    marker="o",
    linewidth=1
)
plt.title("Norte - High-acuity Manchester share")
plt.xlabel("Month")
plt.ylabel("High-acuity share: red + orange / known Manchester-coded attendances")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_high_acuity_manchester_share_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly_final["period"],
    monthly_final["manchester_triage_coverage_share"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Manchester triage coverage share")
plt.xlabel("Month")
plt.ylabel("Known Manchester-coded attendances / total attendances in this dataset")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_manchester_triage_coverage_share_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "norte"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "norte"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "norte" / "ed_admission_share"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

admission_file = RAW_DIR / "inpatients.xlsx"
attendances_file = RAW_DIR / "total_attendences.xlsx"

REGION_RAW = "ARS Norte"
REGION_NAME = "Região de Saúde Norte"

ADMISSION_INDICATOR = "Taxa diária de atendimentos urgentes com internamento"
ATTENDANCES_INDICATOR = "Número estimado de episódios de urgência"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-31")

# ============================================================
# 1. Load daily admission-rate variable: variable 528
# ============================================================

adm = pd.read_excel(admission_file)

adm = adm.rename(columns={
    "Período": "date",
    "Região/ARS": "region_raw",
    "Indicador": "indicator",
    "Valor": "ed_admission_rate_raw",
    "Unidade": "unit",
    "ID": "id"
})

adm["date"] = pd.to_datetime(adm["date"], errors="coerce")
adm["ed_admission_rate_raw"] = pd.to_numeric(adm["ed_admission_rate_raw"], errors="coerce")

adm = adm[
    (adm["region_raw"] == REGION_RAW) &
    (adm["indicator"] == ADMISSION_INDICATOR) &
    (adm["date"] >= START_DATE) &
    (adm["date"] <= END_DATE)
].copy()

adm = adm.sort_values("date").reset_index(drop=True)

# Safety conversion:
# If values are reported as percentages, e.g. 9.5, convert to 0.095.
# If already reported as proportions, e.g. 0.095, keep unchanged.
max_adm_value = adm["ed_admission_rate_raw"].max()

if max_adm_value > 1.5:
    adm["ed_admission_share_daily"] = adm["ed_admission_rate_raw"] / 100
    adm["ed_admission_pct_daily"] = adm["ed_admission_rate_raw"]
else:
    adm["ed_admission_share_daily"] = adm["ed_admission_rate_raw"]
    adm["ed_admission_pct_daily"] = adm["ed_admission_rate_raw"] * 100

# ============================================================
# 2. Load daily total ED attendances: variable 531
# ============================================================

att = pd.read_excel(attendances_file)

att = att.rename(columns={
    "Período": "date",
    "Região/ARS": "region_raw",
    "Indicador": "indicator",
    "Valor": "total_ed_attendances_daily",
    "Unidade": "unit",
    "ID": "id"
})

att["date"] = pd.to_datetime(att["date"], errors="coerce")
att["total_ed_attendances_daily"] = pd.to_numeric(
    att["total_ed_attendances_daily"],
    errors="coerce"
)

att = att[
    (att["region_raw"] == REGION_RAW) &
    (att["indicator"] == ATTENDANCES_INDICATOR) &
    (att["date"] >= START_DATE) &
    (att["date"] <= END_DATE)
].copy()

# In case the raw export has repeated daily rows, aggregate first.
att = (
    att.groupby("date", as_index=False)
       .agg(total_ed_attendances_daily=("total_ed_attendances_daily", "sum"))
       .sort_values("date")
)

# ============================================================
# 3. Merge daily rate with daily attendances
# ============================================================

daily = adm.merge(att, on="date", how="left")

daily["period"] = daily["date"].dt.to_period("M").dt.to_timestamp()
daily["year"] = daily["date"].dt.year
daily["month"] = daily["date"].dt.month

# Estimated daily number of ED attendances followed by inpatient admission
daily["admission_prone_ed_attendances_daily"] = (
    daily["ed_admission_share_daily"] * daily["total_ed_attendances_daily"]
)

# ============================================================
# 4. Raw checks
# ============================================================

print("\n=== RAW DATA CHECKS ===")
print("Rows:", len(daily))
print("Date range:", daily["date"].min(), "to", daily["date"].max())
print("Duplicated dates:", daily.duplicated(subset=["date"]).sum())
print("Missing dates:", daily["date"].isna().sum())
print("Missing admission-rate values:", daily["ed_admission_share_daily"].isna().sum())
print("Missing daily attendances:", daily["total_ed_attendances_daily"].isna().sum())
print("Admission-rate unit:", adm["unit"].dropna().unique())

full_daily_range = pd.date_range(
    daily["date"].min(),
    daily["date"].max(),
    freq="D"
)

missing_days = sorted(set(full_daily_range) - set(daily["date"]))

print("Expected number of days:", len(full_daily_range))
print("Observed number of days:", daily["date"].nunique())
print("Missing calendar days:", len(missing_days))

print("\nInterpretation:")
print("Variable 528 is treated as a daily admission share/rate, not as a cumulative count.")
print("The monthly indicator is computed as an attendance-weighted monthly share.")

# ============================================================
# 5. Monthly aggregation
# ============================================================

monthly = (
    daily.groupby("period", as_index=False)
    .agg(
        total_ed_attendances=("total_ed_attendances_daily", "sum"),
        admission_prone_ed_attendances=("admission_prone_ed_attendances_daily", "sum"),
        ed_admission_share_unweighted_mean=("ed_admission_share_daily", "mean"),
        ed_admission_share_median_daily=("ed_admission_share_daily", "median"),
        ed_admission_share_min_daily=("ed_admission_share_daily", "min"),
        ed_admission_share_max_daily=("ed_admission_share_daily", "max"),
        ed_admission_share_sd_daily=("ed_admission_share_daily", "std"),
        n_days_reported=("date", "nunique")
    )
)

monthly["region"] = REGION_NAME
monthly["days_in_month"] = monthly["period"].dt.days_in_month
monthly["complete_month"] = monthly["n_days_reported"] == monthly["days_in_month"]

monthly["year"] = monthly["period"].dt.year
monthly["month"] = monthly["period"].dt.month

# Main indicator for the pressure index
monthly["ed_admission_share"] = (
    monthly["admission_prone_ed_attendances"] /
    monthly["total_ed_attendances"]
)

monthly["ed_admission_pct"] = monthly["ed_admission_share"] * 100

# Difference between weighted and unweighted monthly estimates
monthly["ed_admission_share_weighting_difference"] = (
    monthly["ed_admission_share"] -
    monthly["ed_admission_share_unweighted_mean"]
)

monthly = monthly[
    [
        "period",
        "region",
        "ed_admission_share",
        "ed_admission_pct",
        "admission_prone_ed_attendances",
        "total_ed_attendances",
        "ed_admission_share_unweighted_mean",
        "ed_admission_share_weighting_difference",
        "ed_admission_share_median_daily",
        "ed_admission_share_min_daily",
        "ed_admission_share_max_daily",
        "ed_admission_share_sd_daily",
        "n_days_reported",
        "days_in_month",
        "complete_month",
        "year",
        "month"
    ]
].sort_values("period").reset_index(drop=True)

# ============================================================
# 6. Monthly checks
# ============================================================

print("\n=== MONTHLY DATA PREVIEW ===")
print(monthly.head())
print(monthly.tail())

print("\n=== COVERAGE ===")
print(monthly["period"].min(), "to", monthly["period"].max())
print("Number of months:", len(monthly))
print("Incomplete months:", (~monthly["complete_month"]).sum())

print("\n=== MAIN INDICATOR SUMMARY ===")
print(monthly[[
    "ed_admission_share",
    "ed_admission_pct",
    "admission_prone_ed_attendances",
    "total_ed_attendances"
]].describe())

print("\n=== INCOMPLETE MONTHS ===")
incomplete = monthly.loc[
    monthly["complete_month"] == False,
    ["period", "n_days_reported", "days_in_month"]
]
print(incomplete if not incomplete.empty else "No incomplete months found.")

# ============================================================
# 7. Save clean files
# ============================================================

out_csv = CLEAN_DIR / "norte_ed_admission_share_monthly.csv"
out_xlsx = CLEAN_DIR / "norte_ed_admission_share_monthly.xlsx"

monthly.to_csv(out_csv, index=False)
monthly.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 8. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["ed_admission_share"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Share of ED attendances admitted as inpatients")
plt.xlabel("Month")
plt.ylabel("ED admission share")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_ed_admission_share_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["ed_admission_share_weighting_difference"],
    marker="o",
    linewidth=1
)
plt.axhline(0, linewidth=1)
plt.title("Norte - Difference between weighted and unweighted monthly admission share")
plt.xlabel("Month")
plt.ylabel("Weighted share minus unweighted daily mean")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_ed_admission_share_weighting_difference.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "norte"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "norte"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "norte" / "mean_waiting_time"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

file_path = RAW_DIR / "mean_wt.xlsx"

REGION_RAW = "ARS Norte"
REGION_NAME = "Região de Saúde Norte"

INDICATOR_NAME = "Tempo médio de espera entre a triagem e a primeira observação médica (rede de urgência hospitalar)"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-31")

# ============================================================
# 1. Load raw data
# ============================================================

df = pd.read_excel(file_path)

df = df.rename(columns={
    "Período": "date",
    "Região/ARS": "region_raw",
    "Indicador": "indicator",
    "Valor": "mean_waiting_time_daily",
    "Unidade": "unit",
    "ID": "id"
})

df["date"] = pd.to_datetime(df["date"], errors="coerce")
df["mean_waiting_time_daily"] = pd.to_numeric(
    df["mean_waiting_time_daily"],
    errors="coerce"
)

# ============================================================
# 2. Filter region, indicator, and study period
# ============================================================

df = df[
    (df["region_raw"] == REGION_RAW) &
    (df["indicator"] == INDICATOR_NAME) &
    (df["date"] >= START_DATE) &
    (df["date"] <= END_DATE)
].copy()

df = df.sort_values("date").reset_index(drop=True)

df["period"] = df["date"].dt.to_period("M").dt.to_timestamp()
df["year"] = df["date"].dt.year
df["month"] = df["date"].dt.month
df["weekday"] = df["date"].dt.day_name()

# ============================================================
# 3. Raw checks
# ============================================================

print("\n=== RAW DATA CHECKS ===")
print("Rows:", len(df))
print("Date range:", df["date"].min(), "to", df["date"].max())
print("Duplicated dates:", df.duplicated(subset=["date"]).sum())
print("Missing dates:", df["date"].isna().sum())
print("Missing values:", df["mean_waiting_time_daily"].isna().sum())
print("Unit:", df["unit"].dropna().unique())

full_daily_range = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
missing_days = sorted(set(full_daily_range) - set(df["date"]))

print("Expected number of days:", len(full_daily_range))
print("Observed number of days:", df["date"].nunique())
print("Missing calendar days:", len(missing_days))

print("\nInterpretation:")
print("Variable 405 is treated as a daily mean waiting time in minutes, not as a cumulative count.")
print("The monthly indicator is computed as the monthly mean of daily mean waiting times.")

# ============================================================
# 4. Monthly aggregation
# ============================================================

monthly = (
    df.groupby("period", as_index=False)
      .agg(
          mean_waiting_time_triage_to_first_obs=("mean_waiting_time_daily", "mean"),
          mean_waiting_time_median_daily=("mean_waiting_time_daily", "median"),
          mean_waiting_time_min_daily=("mean_waiting_time_daily", "min"),
          mean_waiting_time_max_daily=("mean_waiting_time_daily", "max"),
          mean_waiting_time_sd_daily=("mean_waiting_time_daily", "std"),
          mean_waiting_time_p90_daily=("mean_waiting_time_daily", lambda x: x.quantile(0.90)),
          n_days_reported=("date", "nunique")
      )
)

monthly["region"] = REGION_NAME
monthly["days_in_month"] = monthly["period"].dt.days_in_month
monthly["complete_month"] = monthly["n_days_reported"] == monthly["days_in_month"]

monthly["year"] = monthly["period"].dt.year
monthly["month"] = monthly["period"].dt.month

monthly = monthly[
    [
        "period",
        "region",
        "mean_waiting_time_triage_to_first_obs",
        "mean_waiting_time_median_daily",
        "mean_waiting_time_min_daily",
        "mean_waiting_time_max_daily",
        "mean_waiting_time_sd_daily",
        "mean_waiting_time_p90_daily",
        "n_days_reported",
        "days_in_month",
        "complete_month",
        "year",
        "month"
    ]
].sort_values("period").reset_index(drop=True)

# ============================================================
# 5. Monthly checks
# ============================================================

print("\n=== MONTHLY DATA PREVIEW ===")
print(monthly.head())
print(monthly.tail())

print("\n=== COVERAGE ===")
print(monthly["period"].min(), "to", monthly["period"].max())
print("Number of months:", len(monthly))
print("Incomplete months:", (~monthly["complete_month"]).sum())

print("\n=== MAIN INDICATOR SUMMARY ===")
print(monthly[[
    "mean_waiting_time_triage_to_first_obs",
    "mean_waiting_time_median_daily",
    "mean_waiting_time_sd_daily",
    "n_days_reported"
]].describe())

print("\n=== INCOMPLETE MONTHS ===")
incomplete = monthly.loc[
    monthly["complete_month"] == False,
    ["period", "n_days_reported", "days_in_month"]
]
print(incomplete if not incomplete.empty else "No incomplete months found.")

# ============================================================
# 6. Save clean files
# ============================================================

out_csv = CLEAN_DIR / "norte_mean_waiting_time_monthly.csv"
out_xlsx = CLEAN_DIR / "norte_mean_waiting_time_monthly.xlsx"

monthly.to_csv(out_csv, index=False)
monthly.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 7. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["mean_waiting_time_triage_to_first_obs"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Mean waiting time from triage to first medical observation")
plt.xlabel("Month")
plt.ylabel("Mean waiting time, minutes")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_mean_waiting_time_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    monthly["period"],
    monthly["mean_waiting_time_sd_daily"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Within-month daily variability in waiting time")
plt.xlabel("Month")
plt.ylabel("Standard deviation of daily mean waiting time, minutes")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_mean_waiting_time_daily_variability.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure to:")
print(fig_path)

from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "norte"
RAW_DIR = ROOT / "01_data_raw" / "sns" / "norte"
CLEAN_DIR = BASE_DIR / "clean"
EDA_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "09_validation" / "preprocessing"))) / "diagnostics" / "norte" / "downstream_capacity"

CLEAN_DIR.mkdir(parents=True, exist_ok=True)
EDA_DIR.mkdir(parents=True, exist_ok=True)

inpatient_file = RAW_DIR / "inpatient_activity.xlsx"
capacity_file = RAW_DIR / "operated_bed_capacity.xlsx"

# Already created in previous step
admission_file = CLEAN_DIR / "norte_ed_admission_share_monthly.xlsx"

REGION_RAW = "Região de Saúde Norte"
REGION_NAME = "Região de Saúde Norte"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-01")

# ============================================================
# Helper
# ============================================================

def parse_month_column(series):
    """
    Converts SNS monthly period values such as '2017-01'
    or datetime-like values to first day of month.
    """
    return pd.to_datetime(series.astype(str).str.slice(0, 7) + "-01", errors="coerce")


# ============================================================
# 1. Load inpatient activity
# ============================================================

inp = pd.read_excel(inpatient_file)

inp = inp.rename(columns={
    "Período": "period",
    "Região": "region_raw",
    "Instituição": "institution",
    "Localização Geográfica": "geo",
    "Tipo de Especialidade": "specialty_type",
    "Doentes Saídos": "discharges_cum",
    "Dias de Internamento": "inpatient_days_cum"
})

inp["period"] = parse_month_column(inp["period"])
inp["discharges_cum"] = pd.to_numeric(inp["discharges_cum"], errors="coerce")
inp["inpatient_days_cum"] = pd.to_numeric(inp["inpatient_days_cum"], errors="coerce")

inp = inp[
    (inp["region_raw"] == REGION_RAW) &
    (inp["period"] >= START_DATE) &
    (inp["period"] <= END_DATE)
].copy()

inp["year"] = inp["period"].dt.year
inp["month"] = inp["period"].dt.month

print("\n=== INPATIENT ACTIVITY RAW CHECKS ===")
print("Rows:", len(inp))
print("Period:", inp["period"].min(), "to", inp["period"].max())
print("Institutions:", inp["institution"].nunique())
print("Specialty types:", inp["specialty_type"].dropna().unique())

# ============================================================
# 2. Check cumulative behaviour
# ============================================================

# Institutional audit: may show small decreases due to corrections or institutional changes.
audit_records = []

for (inst, spec, year), g in inp.sort_values("period").groupby(
    ["institution", "specialty_type", "year"],
    dropna=False
):
    g = g.sort_values("period")
    for col in ["discharges_cum", "inpatient_days_cum"]:
        diff = g[col].diff()
        decreases = g.loc[diff < 0, ["period", "institution", "specialty_type", col]]

        for _, row in decreases.iterrows():
            audit_records.append({
                "institution": inst,
                "specialty_type": spec,
                "year": year,
                "period": row["period"],
                "variable": col,
                "value": row[col]
            })

institutional_audit = pd.DataFrame(audit_records)
institutional_audit_path = EDA_DIR / "norte_inpatient_activity_institutional_cumulative_decreases.xlsx"
institutional_audit.to_excel(institutional_audit_path, index=False)

print("\nInstitution-level cumulative decreases:", len(institutional_audit))
print("Saved audit:", institutional_audit_path)

# Regional-specialty cumulative series
# We reconstruct monthly flows after aggregating to region-specialty-month.
regional_spec_cum = (
    inp.groupby(["period", "year", "specialty_type"], as_index=False)
       .agg(
           discharges_cum=("discharges_cum", "sum"),
           inpatient_days_cum=("inpatient_days_cum", "sum")
       )
       .sort_values(["specialty_type", "period"])
)

regional_decrease_checks = []

for (spec, year), g in regional_spec_cum.groupby(["specialty_type", "year"], dropna=False):
    g = g.sort_values("period")
    for col in ["discharges_cum", "inpatient_days_cum"]:
        n_decreases = (g[col].diff() < 0).sum()
        regional_decrease_checks.append({
            "specialty_type": spec,
            "year": year,
            "variable": col,
            "n_decreases": int(n_decreases)
        })

regional_decrease_checks = pd.DataFrame(regional_decrease_checks)
regional_decrease_path = EDA_DIR / "norte_inpatient_activity_regional_cumulative_check.xlsx"
regional_decrease_checks.to_excel(regional_decrease_path, index=False)

print("\nRegional cumulative decreases by specialty/year:")
print(regional_decrease_checks.groupby("variable")["n_decreases"].sum())
print("Saved regional cumulative check:", regional_decrease_path)

# ============================================================
# 3. Convert cumulative inpatient activity to monthly flows
# ============================================================

regional_spec_monthly = regional_spec_cum.copy()

for cum_col, monthly_col in [
    ("discharges_cum", "inpatient_discharges"),
    ("inpatient_days_cum", "inpatient_days")
]:
    regional_spec_monthly[monthly_col] = (
        regional_spec_monthly
        .groupby(["specialty_type", "year"])[cum_col]
        .diff()
    )

    first_idx = (
        regional_spec_monthly
        .groupby(["specialty_type", "year"])
        .head(1)
        .index
    )

    regional_spec_monthly.loc[first_idx, monthly_col] = (
        regional_spec_monthly.loc[first_idx, cum_col]
    )

# Check negative monthly flows after reconstruction
negative_inpatient = regional_spec_monthly[
    (regional_spec_monthly["inpatient_days"] < 0) |
    (regional_spec_monthly["inpatient_discharges"] < 0)
].copy()

if len(negative_inpatient) > 0:
    negative_path = EDA_DIR / "norte_inpatient_activity_negative_monthly_flows.xlsx"
    negative_inpatient.to_excel(negative_path, index=False)
    print("\nWARNING: Negative monthly inpatient flows detected.")
    print("Saved:", negative_path)
else:
    print("\nNo negative monthly inpatient flows detected.")

# Pivot specialty components for audit
inpatient_days_by_type = (
    regional_spec_monthly
    .pivot_table(
        index="period",
        columns="specialty_type",
        values="inpatient_days",
        aggfunc="sum"
    )
    .reset_index()
)

discharges_by_type = (
    regional_spec_monthly
    .pivot_table(
        index="period",
        columns="specialty_type",
        values="inpatient_discharges",
        aggfunc="sum"
    )
    .reset_index()
)

inpatient_days_by_type = inpatient_days_by_type.rename(columns={
    "Especialidade Cirurgica": "inpatient_days_surgical",
    "Especialidade Médica": "inpatient_days_medical",
    "Outras Camas": "inpatient_days_other"
})

discharges_by_type = discharges_by_type.rename(columns={
    "Especialidade Cirurgica": "inpatient_discharges_surgical",
    "Especialidade Médica": "inpatient_discharges_medical",
    "Outras Camas": "inpatient_discharges_other"
})

inpatient_monthly = inpatient_days_by_type.merge(
    discharges_by_type,
    on="period",
    how="outer"
)

# Total monthly inpatient activity
inpatient_day_cols = [
    col for col in inpatient_monthly.columns
    if col.startswith("inpatient_days_")
]

discharge_cols = [
    col for col in inpatient_monthly.columns
    if col.startswith("inpatient_discharges_")
]

inpatient_monthly["inpatient_days"] = inpatient_monthly[inpatient_day_cols].sum(axis=1)
inpatient_monthly["inpatient_discharges"] = inpatient_monthly[discharge_cols].sum(axis=1)

# ============================================================
# 4. Load operated bed capacity
# ============================================================

cap = pd.read_excel(capacity_file)

cap = cap.rename(columns={
    "Período": "period",
    "Região": "region_raw",
    "Instituição": "institution",
    "Localização Geográfica": "geo",
    "Tipo de Camas": "bed_type",
    "Lotação": "operated_beds"
})

cap["period"] = parse_month_column(cap["period"])
cap["operated_beds"] = pd.to_numeric(cap["operated_beds"], errors="coerce")

cap = cap[
    (cap["region_raw"] == REGION_RAW) &
    (cap["period"] >= START_DATE) &
    (cap["period"] <= END_DATE)
].copy()

cap["year"] = cap["period"].dt.year
cap["month"] = cap["period"].dt.month

print("\n=== OPERATED BED CAPACITY RAW CHECKS ===")
print("Rows:", len(cap))
print("Period:", cap["period"].min(), "to", cap["period"].max())
print("Institutions:", cap["institution"].nunique())
print("Bed types:", cap["bed_type"].dropna().unique())

# Capacity is a monthly stock variable, not cumulative.
# Therefore, aggregate across institutions and bed types within each month.
capacity_by_type = (
    cap.pivot_table(
        index="period",
        columns="bed_type",
        values="operated_beds",
        aggfunc="sum"
    )
    .reset_index()
)

capacity_by_type = capacity_by_type.rename(columns={
    "Camas Cirúrgicas": "operated_beds_surgical",
    "Camas Médicas": "operated_beds_medical",
    "Camas Neutras": "operated_beds_neutral",
    "Outras Camas": "operated_beds_other"
})

capacity_cols = [
    col for col in capacity_by_type.columns
    if col.startswith("operated_beds_")
]

capacity_by_type["operated_acute_beds"] = capacity_by_type[capacity_cols].sum(axis=1)

# ============================================================
# 5. Compute inpatient bed occupancy rate
# ============================================================

downstream = inpatient_monthly.merge(
    capacity_by_type,
    on="period",
    how="left"
)

downstream["region"] = REGION_NAME
downstream["days_in_month"] = downstream["period"].dt.days_in_month

downstream["inpatient_bed_occupancy_rate"] = (
    downstream["inpatient_days"] /
    (downstream["operated_acute_beds"] * downstream["days_in_month"])
)

downstream["inpatient_bed_occupancy_pct"] = (
    downstream["inpatient_bed_occupancy_rate"] * 100
)

# ============================================================
# 6. Load admission-prone ED attendances
# ============================================================

if not admission_file.exists():
    raise FileNotFoundError(
        f"Missing file: {admission_file}. "
        "Run the ed_admission_share script first."
    )

adm = pd.read_excel(admission_file)
adm["period"] = parse_month_column(adm["period"])

needed_adm_cols = [
    "period",
    "admission_prone_ed_attendances",
    "ed_admission_share",
    "total_ed_attendances"
]

missing_cols = [col for col in needed_adm_cols if col not in adm.columns]

if missing_cols:
    raise ValueError(
        f"The admission file is missing required columns: {missing_cols}"
    )

adm = adm[needed_adm_cols].copy()

downstream = downstream.merge(
    adm,
    on="period",
    how="left"
)

# ============================================================
# 7. Compute admission-prone emergency load per operated acute bed
# ============================================================

downstream["admission_prone_ed_load_per_bed"] = (
    downstream["admission_prone_ed_attendances"] /
    downstream["operated_acute_beds"]
)

# ============================================================
# 8. Final dataset
# ============================================================

downstream["year"] = downstream["period"].dt.year
downstream["month"] = downstream["period"].dt.month

final_cols = [
    "period",
    "region",

    # Indicators for the pressure index
    "inpatient_bed_occupancy_rate",
    "admission_prone_ed_load_per_bed",

    # Readable versions / direct components
    "inpatient_bed_occupancy_pct",
    "inpatient_days",
    "operated_acute_beds",
    "days_in_month",
    "admission_prone_ed_attendances",
    "ed_admission_share",
    "total_ed_attendances",

    # Audit: inpatient activity by specialty
    "inpatient_days_medical",
    "inpatient_days_surgical",
    "inpatient_days_other",
    "inpatient_discharges",
    "inpatient_discharges_medical",
    "inpatient_discharges_surgical",
    "inpatient_discharges_other",

    # Audit: capacity by bed type
    "operated_beds_medical",
    "operated_beds_surgical",
    "operated_beds_neutral",
    "operated_beds_other",

    "year",
    "month"
]

# Ensure optional columns exist even if a category is absent
for col in final_cols:
    if col not in downstream.columns:
        downstream[col] = np.nan

downstream_final = (
    downstream[final_cols]
    .sort_values("period")
    .reset_index(drop=True)
)

# ============================================================
# 9. Checks
# ============================================================

print("\n=== FINAL DOWNSTREAM DATASET CHECKS ===")
print("Period:", downstream_final["period"].min(), "to", downstream_final["period"].max())
print("Number of months:", len(downstream_final))

print("\nMissing values in main indicators:")
print(downstream_final[
    [
        "inpatient_bed_occupancy_rate",
        "admission_prone_ed_load_per_bed",
        "inpatient_days",
        "operated_acute_beds",
        "admission_prone_ed_attendances"
    ]
].isna().sum())

print("\nInpatient bed occupancy rate summary:")
print(downstream_final["inpatient_bed_occupancy_rate"].describe())

print("\nAdmission-prone ED load per bed summary:")
print(downstream_final["admission_prone_ed_load_per_bed"].describe())

print("\nHighest occupancy months:")
print(
    downstream_final
    .sort_values("inpatient_bed_occupancy_rate", ascending=False)
    [["period", "inpatient_bed_occupancy_rate", "inpatient_days", "operated_acute_beds"]]
    .head(10)
)

print("\nLowest occupancy months:")
print(
    downstream_final
    .sort_values("inpatient_bed_occupancy_rate")
    [["period", "inpatient_bed_occupancy_rate", "inpatient_days", "operated_acute_beds"]]
    .head(10)
)

# ============================================================
# 10. Save files
# ============================================================

out_csv = CLEAN_DIR / "norte_downstream_capacity_monthly.csv"
out_xlsx = CLEAN_DIR / "norte_downstream_capacity_monthly.xlsx"

downstream_final.to_csv(out_csv, index=False)
downstream_final.to_excel(out_xlsx, index=False)

print("\n=== SAVED CLEAN FILES ===")
print(out_csv)
print(out_xlsx)

# ============================================================
# 11. EDA plots
# ============================================================

plt.figure(figsize=(11, 4))
plt.plot(
    downstream_final["period"],
    downstream_final["inpatient_bed_occupancy_rate"],
    marker="o",
    linewidth=1
)
plt.axhline(1.0, linewidth=1)
plt.title("Norte - Inpatient bed occupancy rate")
plt.xlabel("Month")
plt.ylabel("Occupancy rate")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_inpatient_bed_occupancy_rate_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure:", fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    downstream_final["period"],
    downstream_final["admission_prone_ed_load_per_bed"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Admission-prone ED load per operated acute bed")
plt.xlabel("Month")
plt.ylabel("Admission-prone ED attendances per operated acute bed")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_admission_prone_ed_load_per_bed_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure:", fig_path)

plt.figure(figsize=(11, 4))
plt.plot(
    downstream_final["period"],
    downstream_final["operated_acute_beds"],
    marker="o",
    linewidth=1
)
plt.title("Norte - Operated acute bed capacity")
plt.xlabel("Month")
plt.ylabel("Operated acute beds")
plt.grid(True, alpha=0.3)
plt.tight_layout()

fig_path = EDA_DIR / "norte_operated_acute_beds_monthly.png"
plt.savefig(fig_path, dpi=300)
plt.close("all")

print("Saved figure:", fig_path)

from pathlib import Path
import pandas as pd

# ============================================================
# Paths
# ============================================================

BASE_DIR = Path(os.environ.get("THESIS_PREPROCESS_WORKDIR", str(ROOT / "02_data_intermediate"))) / "norte"
CLEAN_DIR = BASE_DIR / "clean"

OUT_FILE_XLSX = CLEAN_DIR / "norte_pressure_index_indicators_monthly.xlsx"
OUT_FILE_CSV = CLEAN_DIR / "norte_pressure_index_indicators_monthly.csv"

REGION_NAME = "Região de Saúde Norte"

START_DATE = pd.Timestamp("2017-01-01")
END_DATE = pd.Timestamp("2025-12-01")

# ============================================================
# Helper function
# ============================================================

def load_indicator(file_name, cols):
    df = pd.read_excel(CLEAN_DIR / file_name)
    df["period"] = pd.to_datetime(df["period"], errors="coerce")
    return df[cols].copy()

# ============================================================
# 1. Load only the required indicator columns
# ============================================================

# 1) Demand-side load
total_ed = load_indicator(
    "norte_total_ed_attendances_monthly.xlsx",
    ["period", "region", "total_ed_attendances"]
)

# 2) Demand severity / case mix
high_acuity = load_indicator(
    "norte_high_acuity_manchester_share_monthly.xlsx",
    ["period", "region", "high_acuity_manchester_share"]
)

# 3) Admission-prone demand
admission_share = load_indicator(
    "norte_ed_admission_share_monthly.xlsx",
    ["period", "region", "ed_admission_share"]
)

# 4) Internal flow limitation
waiting_time = load_indicator(
    "norte_mean_waiting_time_monthly.xlsx",
    ["period", "region", "mean_waiting_time_triage_to_first_obs"]
)

# 5 and 6) Downstream saturation + demand-capacity coupling
downstream = load_indicator(
    "norte_downstream_capacity_monthly.xlsx",
    [
        "period",
        "region",
        "inpatient_bed_occupancy_rate",
        "admission_prone_ed_load_per_bed"
    ]
)

# ============================================================
# 2. Merge all indicators
# ============================================================

dfs = [
    total_ed,
    high_acuity,
    admission_share,
    waiting_time,
    downstream
]

panel = dfs[0]

for df in dfs[1:]:
    panel = panel.merge(
        df,
        on=["period", "region"],
        how="outer",
        validate="one_to_one"
    )

# ============================================================
# 3. Restrict study period and order columns
# ============================================================

panel = panel[
    (panel["period"] >= START_DATE) &
    (panel["period"] <= END_DATE)
].copy()

panel["region"] = REGION_NAME

indicator_cols = [
    "total_ed_attendances",
    "high_acuity_manchester_share",
    "ed_admission_share",
    "mean_waiting_time_triage_to_first_obs",
    "inpatient_bed_occupancy_rate",
    "admission_prone_ed_load_per_bed"
]

panel = panel[
    ["period", "region"] + indicator_cols
].sort_values("period").reset_index(drop=True)

# ============================================================
# 4. Checks
# ============================================================

print("\n=== FINAL PRESSURE INDICATOR PANEL - NORTE ===")
print(panel.head())
print(panel.tail())

print("\nCoverage:")
print(panel["period"].min(), "to", panel["period"].max())
print("Number of months:", len(panel))

print("\nMissing values by column:")
print(panel.isna().sum())

print("\nDuplicated period-region rows:")
print(panel.duplicated(subset=["period", "region"]).sum())

print("\nDescriptive statistics:")
print(panel[indicator_cols].describe())

# Expected number of months: 2017-01 to 2025-12 = 108
expected_months = pd.date_range(START_DATE, END_DATE, freq="MS")
missing_months = sorted(set(expected_months) - set(panel["period"]))

print("\nMissing months:")
print(missing_months if missing_months else "No missing months.")

if len(panel) != len(expected_months):
    print("\nWARNING: Number of months differs from expected.")
else:
    print("\nMonth count is correct.")

if panel[indicator_cols].isna().sum().sum() > 0:
    print("\nWARNING: Missing indicator values detected.")
else:
    print("\nNo missing indicator values detected.")

# ============================================================
# 5. Save final clean indicator panel
# ============================================================

panel.to_excel(OUT_FILE_XLSX, index=False)
panel.to_csv(OUT_FILE_CSV, index=False)

print("\nSaved files:")
print(OUT_FILE_XLSX)
print(OUT_FILE_CSV)