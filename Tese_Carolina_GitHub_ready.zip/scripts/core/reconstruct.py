"""Reconstruction from preserved monthly data, not recovered original code.
Run: python reconstruct.py --inputs /path/to/upload
Fixed primary specification: six raw indicators + full region one-hot, numeric
training-only StandardScaler, sklearn ridge logistic C=10, lbfgs, no class weights.
Annual development fits; frozen 2017-2024 pressure definition and monthly 2025 fits.
No configuration is selected against the 2025 results.
"""
import argparse, json, hashlib, platform
from pathlib import Path
import numpy as np
import pandas as pd
import scipy
from scipy.special import expit, logit
from scipy.optimize import minimize, brentq
from scipy.linalg import expm
from scipy.stats import spearmanr
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, log_loss, confusion_matrix

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'08_results'/'numerical_results';OUT.mkdir(parents=True,exist_ok=True)
FEATURES=['total_ed_attendances','high_acuity_manchester_share','ed_admission_share',
 'mean_waiting_time_triage_to_first_obs','inpatient_bed_occupancy_rate','admission_prone_ed_load_per_bed']
SEED=20261008

def save(obj,name):
    if isinstance(obj,pd.DataFrame):obj.to_csv(OUT/(name+'.csv'),index=False)
    else:(OUT/(name+'.json')).write_text(json.dumps(obj,indent=2,ensure_ascii=False,default=str))

def metrics(y,p):
    y=np.asarray(y,int);p=np.asarray(p,float);both=len(np.unique(y))==2
    return dict(n=len(y),events=int(y.sum()),prevalence=y.mean(),mean_risk=p.mean(),
        AUROC=roc_auc_score(y,p) if both else np.nan,
        AUPRC=average_precision_score(y,p) if y.sum() else np.nan,
        Brier=brier_score_loss(y,p),LogLoss=(np.nan if np.all((p==0)|(p==1)) else log_loss(y,np.clip(p,1e-15,1-1e-15),labels=[0,1])),Bias=(p-y).mean())

def threshold(y,p,c):
    tn,fp,fn,tp=confusion_matrix(y,np.asarray(p)>=c,labels=[0,1]).ravel()
    sens=tp/(tp+fn) if tp+fn else np.nan;spec=tn/(tn+fp) if tn+fp else np.nan
    return dict(threshold=c,TP=int(tp),TN=int(tn),FP=int(fp),FN=int(fn),Sensitivity=sens,
     Specificity=spec,PPV=tp/(tp+fp) if tp+fp else np.nan,BalancedAccuracy=(sens+spec)/2,
     AlertRate=(tp+fp)/len(y),MissedEventRate=1-sens)

def pressure(df,year):
    hist=df.period.dt.year<year;x=df[FEATURES]
    mu=x[hist].mean();sd=x[hist].std(ddof=0);pi=((x-mu)/sd).mean(axis=1)
    s=pd.Series(0,index=df.index,dtype=int);cuts={}
    for r in sorted(df.region.unique()):
        mask=df.region==r;q=np.quantile(pi[mask&hist],[.2,.4,.6,.8],method='linear')
        s.loc[mask]=np.searchsorted(q,pi[mask],side='left')+1;cuts[r]=q.tolist()
    return pi,s,dict(year=year,means=mu.to_dict(),std_ddof0=sd.to_dict(),cutpoints=cuts)

def pairs(df,year):
    pi,s,params=pressure(df,year)
    a=df[['period','region']+FEATURES].copy();a['PI']=pi;a['state']=s
    g=a.groupby('region',sort=False)
    a['target_month']=g.period.shift(-1);a['target_state']=g.state.shift(-1)
    a['index_change']=g.PI.diff()
    a=a.dropna(subset=['target_month','target_state']).copy()
    a['y']=(a.target_state>=4).astype(int)
    return a,params

def model(region=True):
    trans=[('numeric',StandardScaler(),FEATURES)]
    if region:trans.append(('region',OneHotEncoder(handle_unknown='ignore',sparse_output=False),['region']))
    return make_pipeline(ColumnTransformer(trans),LogisticRegression(C=10.,solver='lbfgs',max_iter=10000,tol=1e-10))

def predict(train,test,region=True):
    m=model(region);m.fit(train,train.y);return m,m.predict_proba(test)[:,1]

def benchmarks(train,test):
    counts=pd.crosstab(train.state,train.target_state).reindex(index=range(1,6),columns=range(1,6),fill_value=0)
    prob=counts.div(counts.sum(axis=1),axis=0)
    if prob.isna().any().any():raise ValueError('Empty transition row: smoothing must be specified')
    return dict(DTMC=test.state.map(prob[[4,5]].sum(axis=1)).to_numpy(),
      Prevalence=test.region.map(train.groupby('region').y.mean()).to_numpy(),
      Persistence=(test.state>=4).astype(float).to_numpy())

def records(test,preds,stage):
    a=test[['region','period','target_month','state','target_state','y']].copy();a['stage']=stage
    for key,p in preds.items():a[key]=p
    return a

def describe(df):
    a=df.sort_values(['region','period']).copy();a['next']=a.groupby('region').S_ref.shift(-1)
    n=pd.crosstab(a.S_ref,a['next']).reindex(index=range(1,6),columns=range(1,6),fill_value=0)
    p=n.to_numpy()/n.sum(axis=1).to_numpy()[:,None]
    save(n.reset_index(),'transition_counts');save(pd.DataFrame(p,index=range(1,6),columns=range(1,6)).reset_index(),'transition_probabilities')
    rows=[]
    for h in [1,3,6]:
        for i,v in enumerate(np.linalg.matrix_power(p,h)[:,3:].sum(axis=1)):rows.append(dict(horizon=h,state=i+1,probability=v))
    save(pd.DataFrame(rows),'dtmc_horizons')
    episodes=[]
    for r,g in a.groupby('region'):
        run=[]
        for j,(_,row) in enumerate(g.iterrows()):
            if row.S_ref>=4:run.append(row.period)
            if run and (row.S_ref<4 or j==len(g)-1):
                episodes.append(dict(region=r,start=run[0],end=run[-1],months=len(run),
                  left_censored=run[0]==g.period.min(),right_censored=run[-1]==g.period.max()));run=[]
    save(pd.DataFrame(episodes),'episodes')
    # Adjacent CTMC, exact monthly transition likelihood; independent reconstruction.
    edges=[(i,j) for i in range(5) for j in range(5) if abs(i-j)==1]
    def generator(theta):
        q=np.zeros((5,5))
        for k,(i,j) in enumerate(edges):q[i,j]=np.exp(theta[k])
        q[np.diag_indices(5)]=-q.sum(axis=1);return q
    def objective(theta):return -np.sum(n.to_numpy()*np.log(np.clip(expm(generator(theta)),1e-15,1)))
    fits=[minimize(objective,np.full(8,np.log(start)),method='L-BFGS-B',bounds=[(-12,4)]*8) for start in [.1,.5,1.]]
    best=min(fits,key=lambda x:x.fun);q=generator(best.x)
    save(dict(success=bool(best.success),message=str(best.message),negative_loglikelihood=best.fun,
      all_fits=[dict(success=bool(f.success),nll=f.fun) for f in fits],Q=q.tolist(),
      horizons=[dict(horizon=h,probabilities=expm(q*h)[:,3:].sum(axis=1).tolist(),
      mean_abs_difference=float(abs(expm(q*h)[:,3:].sum(axis=1)-np.linalg.matrix_power(p,h)[:,3:].sum(axis=1)).mean()),
      max_abs_difference=float(abs(expm(q*h)[:,3:].sum(axis=1)-np.linalg.matrix_power(p,h)[:,3:].sum(axis=1)).max())) for h in [1,3,6]]),'ctmc_reconstruction')

def bootstrap(a,left,right,name,reps=3000,block=3):
    # Non-circular moving blocks over the full calendar; retain cross-region dependence.
    a=a.sort_values(['target_month','region']).reset_index(drop=True)
    months=pd.date_range(a.target_month.min(),a.target_month.max(),freq='MS')
    groups=[np.where(a.target_month==m)[0] for m in months];rng=np.random.default_rng(SEED)
    keys=['AUROC','AUPRC','Brier','LogLoss'];vals={k:[] for k in keys};individual={m:{k:[] for k in keys} for m in [left,right]}
    for _ in range(reps):
        starts=rng.integers(0,len(months)-block+1,size=int(np.ceil(len(months)/block)))
        mi=np.concatenate([np.arange(s,s+block) for s in starts])[:len(months)]
        ids=np.concatenate([groups[j] for j in mi])
        if len(ids)==0 or a.iloc[ids].y.nunique()<2:continue
        b=a.iloc[ids];ml=metrics(b.y,b[left]);mr=metrics(b.y,b[right])
        for k in keys:
            vals[k].append(ml[k]-mr[k]);individual[left][k].append(ml[k]);individual[right][k].append(mr[k])
    pointl=metrics(a.y,a[left]);pointr=metrics(a.y,a[right]);rows=[]
    for k in keys:
        lo,hi=np.quantile(vals[k],[.025,.975]);rows.append(dict(comparison=left+' minus '+right,metric=k,point=pointl[k]-pointr[k],bootstrap_mean=float(np.mean(vals[k])),lower=lo,upper=hi,valid_replicates=len(vals[k]),block_months=block))
        for m,point in [(left,pointl),(right,pointr)]:
            lo,hi=np.quantile(individual[m][k],[.025,.975]);rows.append(dict(comparison=m,metric=k,point=point[k],lower=lo,upper=hi,valid_replicates=len(vals[k]),block_months=block))
    save(pd.DataFrame(rows),name)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=Path,required=True);args=ap.parse_args()
    df=pd.read_csv(args.inputs.parent/'regional_monthly_reference.csv',parse_dates=['period']).sort_values(['region','period']).reset_index(drop=True)
    ex=pd.read_excel(args.inputs/'exo(2).xlsx');assert len(df)==540 and not df.duplicated(['region','period']).any()
    assert not df[FEATURES].isna().any().any();assert len(df.merge(ex,on=['region','period'],validate='one_to_one'))==540
    pi,s,par=pressure(df,2025);assert np.allclose(pi,df.PI_ref,atol=1e-12);assert np.array_equal(s,df.S_ref)
    save(dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,seed=SEED,
      source_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in args.inputs.glob('*') if p.suffix in ['.xlsx','.pdf','.zip']},
      primary_C=10,numerical_scaling='training StandardScaler ddof=0',categorical_encoding='all region indicators, no drop',
      threshold_original=.6,AUPRC_definition='average_precision_score; original implementation unavailable'), 'provenance')
    allp=[];parameters=[];geo=[];fits=[]
    for year in [2021,2022,2023,2024]:
        a,par=pairs(df,year);parameters.append(par);tr=a[a.target_month.dt.year<year];te=a[a.target_month.dt.year==year]
        m,p=predict(tr,te);_,pn=predict(tr,te,False)
        allp.append(records(te,dict(Ridge=p,NoRegion=pn,**benchmarks(tr,te)),'development'))
        fits.append(dict(stage='development',year=year,train_n=len(tr),test_n=len(te),train_last_target=tr.target_month.max(),test_first_target=te.target_month.min()))
        for r in sorted(df.region.unique()):
            other=tr[tr.region!=r];local=tr[tr.region==r];test=te[te.region==r]
            gm,gp=predict(other,test,False);lp=gm.predict_proba(local)[:,1];offset=logit(np.clip(lp,1e-12,1-1e-12))
            delta=brentq(lambda d:(expit(offset+d)-local.y).sum(),-50,50)
            gp_adapt=expit(logit(np.clip(gp,1e-12,1-1e-12))+delta)
            g=records(test,dict(Direct=gp,Adapted=gp_adapt),'geographical');g['delta']=delta;geo.append(g)
    a,par=pairs(df,2025);parameters.append(par)
    for month in pd.date_range('2025-01-01','2025-12-01',freq='MS'):
        tr=a[a.target_month<month];te=a[a.target_month==month];_,p=predict(tr,te)
        allp.append(records(te,dict(Ridge=p,**benchmarks(tr,te)),'holdout_monthly'))
        fits.append(dict(stage='holdout_monthly',year=str(month.date()),train_n=len(tr),test_n=len(te),train_last_target=tr.target_month.max(),test_first_target=te.target_month.min()))
    # Prespecified audit sensitivity to update frequency; no tuning on 2025.
    tr=a[a.target_month<'2025-01-01'];te=a[a.target_month.dt.year==2025];_,p=predict(tr,te)
    frozen=records(te,dict(Ridge=p,**benchmarks(tr,te)),'holdout_annual');save(frozen,'predictions_2025_annual_sensitivity')
    predictions=pd.concat(allp,ignore_index=True);geographical=pd.concat(geo,ignore_index=True)
    save(predictions,'predictions_primary');save(geographical,'predictions_geographical');save(parameters,'pressure_parameters');save(pd.DataFrame(fits),'training_windows')
    scores=[]
    for stage,g in predictions.groupby('stage'):
        for mod in ['Ridge','DTMC','Prevalence','Persistence','NoRegion']:
            if mod in g and g[mod].notna().all():scores.append(dict(stage=stage,model=mod,**metrics(g.y,g[mod])))
    for mod in ['Ridge','DTMC','Prevalence','Persistence']:scores.append(dict(stage='holdout_annual',model=mod,**metrics(frozen.y,frozen[mod])))
    for mod in ['Direct','Adapted']:scores.append(dict(stage='geographical',model=mod,**metrics(geographical.y,geographical[mod])))
    dev=predictions[predictions.stage=='development'];inc=dev[dev.state<=3];final=predictions[predictions.stage=='holdout_monthly']
    for mod in ['Ridge','DTMC']:scores.append(dict(stage='incident_development',model=mod,**metrics(inc.y,inc[mod])))
    save(pd.DataFrame(scores),'scores_pooled')
    annual=[]
    for year,g in predictions.groupby(predictions.target_month.dt.year):
        for mod in ['Ridge','DTMC','Prevalence','Persistence']:annual.append(dict(year=year,model=mod,**metrics(g.y,g[mod])))
    save(pd.DataFrame(annual),'scores_annual')
    regional=[]
    for r,g in geographical.groupby('region'):
        for mod in ['Direct','Adapted']:regional.append(dict(region=r,model=mod,**metrics(g.y,g[mod])))
    save(pd.DataFrame(regional),'scores_geographical_regions')
    grid=pd.DataFrame([threshold(dev.y,dev.Ridge,round(float(c),2)) for c in np.arange(.2,.80001,.05)])
    save(grid,'threshold_development');eligible=grid[grid.MissedEventRate<=.2].sort_values(['AlertRate','BalancedAccuracy'],ascending=[True,False]);selected=float(eligible.iloc[0].threshold)
    mon=[]
    for label,g in [('development',dev),('holdout_monthly',final),('incident_development',inc)]:
        mon.append(dict(stage=label,**threshold(g.y,g.Ridge,.6)))
    save(pd.DataFrame(mon),'monitoring_original_threshold');save(dict(reconstructed_threshold=selected,original_threshold=.6),'threshold_selection')
    describe(df)
    print(pd.DataFrame(scores).round(6).to_string(index=False),flush=True)
    print('Bootstrap: conditional on reconstructed predictions; selection not repeated.',flush=True)
    bootstrap(inc,'Ridge','DTMC','bootstrap_incident')
    bootstrap(final,'Ridge','DTMC','bootstrap_2025',reps=3000)
    bootstrap(geographical,'Adapted','Direct','bootstrap_adaptation',reps=3000)
    print('Reconstruction complete',flush=True)

if __name__=='__main__':main()
