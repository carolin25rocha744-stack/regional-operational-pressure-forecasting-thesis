"""Additional independent reconstruction: index robustness, hours and calibration.
Run after reconstruct.py. Implementation choices are explicit, not original code.
"""
import argparse,unicodedata,json
from itertools import product
import numpy as np
import pandas as pd
from scipy.stats import spearmanr,mannwhitneyu
from scipy.optimize import minimize
from scipy.special import expit,logit
from sklearn.metrics import balanced_accuracy_score
from reconstruct import FEATURES,OUT,save,SEED

def states(df,pi,levels=5,scope='region'):
    s=pd.Series(0,index=df.index,dtype=int);dev=df.period.dt.year<2025
    for r in (sorted(df.region.unique()) if scope=='region' else ['all']):
        mask=(df.region==r) if r!='all' else pd.Series(True,index=df.index)
        q=np.quantile(pi[mask&dev],np.arange(1,levels)/levels)
        s.loc[mask]=np.searchsorted(q,pi[mask],side='left')+1
    return s

def robustness(df):
    dev=df.period.dt.year<2025;x=df[FEATURES];ref=df.PI_ref;rs=df.S_ref
    z=(x-x[dev].mean())/x[dev].std(ddof=0)
    save(x[dev].corr(method='spearman').reset_index(),'indicator_correlations')
    def compare(pi,s,mask):
        n=int(np.ceil(mask.sum()*.2));a=set(pi[mask].nlargest(n).index);b=set(ref[mask].nlargest(n).index)
        return dict(Spearman=spearmanr(pi[mask],ref[mask]).statistic,Top20Overlap=len(a&b)/n,
          Exact=np.mean(s[mask]==rs[mask]),Adjacent=np.mean(abs(s[mask]-rs[mask])<=1),BalancedAccuracy=balanced_accuracy_score(rs[mask]>=4,s[mask]>=4))
    rows=[]
    for omitted in FEATURES:
        pi=z.drop(columns=omitted).mean(axis=1);s=states(df,pi)
        rows.append(dict(omitted=omitted,**compare(pi,s,dev)))
    save(pd.DataFrame(rows),'leave_one_indicator_out')
    rows=[];all_states={};allmask=pd.Series(True,index=df.index)
    for norm,scope,weight in product(['z','minmax'],['pool','region'],['equal','domain','critic']):
        scaled=x.copy()*0
        for r in (sorted(df.region.unique()) if scope=='region' else ['all']):
            mask=(df.region==r) if r!='all' else allmask;hist=x[mask&dev]
            loc=hist.mean() if norm=='z' else hist.min();scale=hist.std(ddof=0) if norm=='z' else hist.max()-hist.min()
            scaled.loc[mask]=(x[mask]-loc)/scale
        if weight=='equal':w=np.ones(6)/6
        elif weight=='domain':w=np.array([1/9,1/9,1/9,1/3,1/6,1/6])
        else:
            sd=scaled[dev].std(ddof=0);rho=scaled[dev].corr();info=sd*(1-rho).sum();w=(info/info.sum()).to_numpy()
        pi=scaled@w
        for level,cut_scope in product([4,5],['region','pool']):
            name=f'{scope}_{norm}_{weight}_{level}_{cut_scope}';s=states(df,pi,level,cut_scope)
            row=dict(specification=name,weights=json.dumps(w.tolist()),levels=level,cut_scope=cut_scope,
                Spearman=spearmanr(pi,ref).statistic,ScaledDistance=np.mean(abs((s-1)/(level-1)-(rs-1)/4)))
            if level==5:row.update(compare(pi,s,allmask));all_states[name]=s
            rows.append(row)
    save(pd.DataFrame(rows),'robustness_48_specs')
    alts={k:v for k,v in all_states.items() if k!='pool_z_equal_5_region'}
    consensus=(pd.DataFrame(alts)>=4).mean(axis=1)
    save(pd.DataFrame({'state':rs,'consensus':consensus}).groupby('state').consensus.agg(['mean','count']).reset_index(),'consensus')

def lowess(x,y,frac=.75,it=0):
    # Local linear LOWESS with tricube distance weights; optional residual robustness.
    x=np.asarray(x);y=np.asarray(y);n=len(x);k=max(2,int(frac*n));rw=np.ones(n)
    for iteration in range(it+1):
        fit=np.empty(n)
        for i in range(n):
            d=abs(x-x[i]);radius=np.sort(d)[k-1]
            w=(np.clip(1-(d/max(radius,1e-15))**3,0,None)**3)*rw
            xx=x-x[i];design=np.column_stack([np.ones(n),xx]);sw=np.sqrt(w)
            fit[i]=np.linalg.lstsq(design*sw[:,None],y*sw,rcond=None)[0][0]
        med=np.median(abs(y-fit))
        if med<1e-14:break
        rw=np.clip(1-((y-fit)/(6*med))**2,0,None)**2
    return fit

def calibration():
    a=pd.read_csv(OUT/'predictions_primary.csv',parse_dates=['target_month']);rows=[]
    for label,g in [('development',a[a.stage=='development']),('2025',a[a.stage=='holdout_monthly'])]+[(str(y),g) for y,g in a[a.stage=='development'].groupby(a.target_month.dt.year)]:
        p=g.Ridge.to_numpy();y=g.y.to_numpy();xx=logit(np.clip(p,1e-12,1-1e-12));X=np.column_stack([np.ones(len(p)),xx])
        f=minimize(lambda b:np.sum(np.logaddexp(0,X@b)-y*(X@b)),[0.,1.],jac=lambda b:X.T@(expit(X@b)-y),method='BFGS',options={'gtol':1e-9})
        for it in [0,3]:rows.append(dict(sample=label,frac=.75,robust_iterations=it,ICI=np.mean(abs(p-lowess(p,y,it=it))),intercept=f.x[0],slope=f.x[1],optimizer_success=bool(f.success),gradient_norm=float(np.linalg.norm(f.jac))))
    save(pd.DataFrame(rows),'calibration_reconstruction')

def hours(df,path):
    a=pd.read_excel(path);a['period']=pd.to_datetime(a['Período']);a=a[a.period.dt.year<=2024].copy()
    def norm(t):return ''.join(c for c in unicodedata.normalize('NFD',t.lower()) if unicodedata.category(c)!='Mn')
    names=a.Entidade.map(norm)
    hospital=names.str.startswith(('hospital','centro hospital','unidade local','instituto port','inst.port','centro medicina','instituto de oftalmologia'))
    save(pd.DataFrame({'entity':a.Entidade,'included_hospital_rule':hospital}).drop_duplicates(),'hours_entity_filter')
    a=a[hospital].copy();components=['Trabalho Suplementar Diurno','Trabalho Suplementar Nocturno','Trabalho em Dias de Descanso Semanal Obrigatório','Trabalho em Dias de Descanso Semanal Complementar','Trabalho em Dias Feriados']
    a['cum']=a[components].sum(axis=1)
    b=a.groupby(['Região','period']).agg(cumulative=('cum','sum'),entities=('Entidade','nunique')).reset_index().rename(columns={'Região':'region'}).sort_values(['region','period'])
    b['year']=b.period.dt.year;b['monthly']=b.groupby(['region','year']).cumulative.diff();jan=b.period.dt.month==1;b.loc[jan,'monthly']=b.loc[jan,'cumulative']
    # Cumulative series restart each January; no cross-year differencing is used.
    # Coverage exclusion applies within the year, where differencing combines entities.
    b['count_changed']=b.groupby(['region','year']).entities.diff().fillna(0)!=0
    b['invalid_negative']=b.monthly<0;b['included']=~(b.count_changed|b.invalid_negative|b.monthly.isna())
    save(b,'hours_monthly_qc');c=b[b.included].merge(df[['period','region','PI_ref','S_ref']],on=['period','region'],validate='one_to_one')
    c['burden_z']=c.groupby('region').monthly.transform(lambda v:(v-v.mean())/v.std(ddof=0))
    def residuals(c):
        design=pd.get_dummies(c.region+'_'+c.year.astype(str),dtype=float)
        design=pd.concat([design,pd.get_dummies(c.period.dt.month,prefix='m',dtype=float)],axis=1).to_numpy()
        vals=c[['PI_ref','burden_z']].to_numpy();return vals-design@np.linalg.lstsq(design,vals,rcond=None)[0]
    raw=spearmanr(c.PI_ref,c.burden_z);res=residuals(c);adjusted=spearmanr(res[:,0],res[:,1]);c['pressure_residual']=res[:,0];c['burden_residual']=res[:,1]
    save(c,'hours_analysis_panel');summary=dict(n=len(c),raw_rho=raw.statistic,raw_nominal_p=raw.pvalue,
      state_rho=spearmanr(c.S_ref,c.burden_z).statistic,adjusted_rho=adjusted.statistic,adjusted_nominal_p=adjusted.pvalue,
      mean_non_elevated=c.loc[c.S_ref<=3,'burden_z'].mean(),mean_elevated=c.loc[c.S_ref>=4,'burden_z'].mean(),
      original_record_linkage_unavailable=True,filter_rule='normalized entity name prefix; retained table for manual review')
    ev=c.loc[c.S_ref>=4,'burden_z'];ne=c.loc[c.S_ref<=3,'burden_z'];u=mannwhitneyu(ev,ne,alternative='two-sided');summary['rank_biserial']=2*u.statistic/(len(ev)*len(ne))-1
    summary['rank_biserial_nominal_p']=u.pvalue
    cc=c[c.year<2024];rr=residuals(cc);summary['pre2024_n']=len(cc);summary['pre2024_adjusted_rho']=spearmanr(rr[:,0],rr[:,1]).statistic
    for r in sorted(c.region.unique()):
        rr=residuals(c[c.region!=r]);summary['without_'+r]=spearmanr(rr[:,0],rr[:,1]).statistic
    save(summary,'hours_summary');print('HOURS',summary,flush=True)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--inputs',type=__import__('pathlib').Path,required=True);args=ap.parse_args()
    df=pd.read_csv(args.inputs.parent/'regional_monthly_reference.csv',parse_dates=['period']).sort_values(['region','period']).reset_index(drop=True)
    robustness(df);calibration();hours(df,args.inputs/'horas.xlsx')
