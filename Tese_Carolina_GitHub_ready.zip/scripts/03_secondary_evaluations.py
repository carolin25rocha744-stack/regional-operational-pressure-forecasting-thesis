"""Robustez, calibração e horas; executar após 02."""
import subprocess
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if __name__ == '__main__':
    subprocess.run([sys.executable, str(ROOT/'scripts/core/supplement.py'), '--inputs', str(ROOT/'03_analytical_dataset/processed_inputs')], check=True)
