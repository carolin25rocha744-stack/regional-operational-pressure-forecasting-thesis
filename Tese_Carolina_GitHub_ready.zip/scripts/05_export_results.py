"""Exporta vistas por etapa dos resultados da reprodução C=10."""
from pathlib import Path
import shutil
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'08_results/numerical_results'

def main():
    p = pd.read_csv(SOURCE/'predictions_primary.csv')
    p[p.stage=='development'].to_csv(ROOT/'05_model_development/development_predictions_c10.csv',index=False)
    p[p.stage=='holdout_monthly'].to_csv(ROOT/'06_final_evaluation_2025/monthly_predictions_ridge_dtmc.csv',index=False)
    scores = pd.read_csv(SOURCE/'scores_pooled.csv')
    scores[scores.stage=='holdout_monthly'].to_csv(ROOT/'06_final_evaluation_2025/final_metrics.csv',index=False)
    scores[scores.stage=='development'].to_csv(ROOT/'05_model_development/development_metrics.csv',index=False)
    for f in SOURCE.glob('*'):
        n=f.name
        if any(s in n for s in ['transition_', 'dtmc_horizons', 'episodes', 'robustness', 'consensus', 'indicator_correlations', 'leave_one']): folder='04_analysis'
        elif any(s in n for s in ['bootstrap', 'geograph', 'threshold', 'calibration', 'monitoring', 'hours_']):folder='07_secondary_evaluations'
        else:continue
        shutil.move(str(f),str(ROOT/folder/n))
    print('Exportadas previsões e métricas por etapa.')

if __name__=='__main__':main()
