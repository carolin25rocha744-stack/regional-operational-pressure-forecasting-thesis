"""Generate figures from reconstructed predictions, not transcribed point estimates."""
from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve
ROOT=Path(__file__).resolve().parents[1]/'08_results';OUT=ROOT/'figures';OUT.mkdir(parents=True,exist_ok=True)
plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none'})
def write(fig,name):
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight');fig.savefig(OUT/(name+'.png'),dpi=200,bbox_inches='tight');plt.close(fig)
p=pd.read_csv(ROOT/'numerical_results/predictions_primary.csv');h=p[p.stage=='holdout_monthly']
fig,ax=plt.subplots(figsize=(5.8,4.8))
for name,col in [('Ridge','#155d8b'),('DTMC','#b96724')]:
    f,t,_=roc_curve(h.y,h[name]);ax.plot(f,t,label=name,color=col,lw=2)
ax.plot([0,1],[0,1],':',color='#666');ax.set(xlabel='False-positive rate',ylabel='True-positive rate',title='2025: monthly sequential evaluation',xlim=(0,1),ylim=(0,1));ax.legend();write(fig,'2025_roc_ridge_dtmc')
s=pd.read_csv(ROOT/'numerical_results/scores_pooled.csv');s=s[s.stage=='holdout_monthly'].set_index('model')
fig,axs=plt.subplots(1,2,figsize=(9,4))
for ax,metric in zip(axs,['Brier','LogLoss']):
    names=['Ridge','DTMC','Prevalence'];vals=s.loc[names,metric];ax.bar(names,vals,color=['#155d8b','#b96724','#999']);ax.set(ylabel=metric,title='Lower is better')
    for j,v in enumerate(vals):ax.text(j,v+.008,f'{v:.4f}',ha='center',fontsize=11)
    ax.set_ylim(0,max(vals)*1.23)
fig.suptitle('2025 probability scores: matching monthly updates');fig.tight_layout();write(fig,'2025_probability_scores')
b=pd.read_csv(ROOT/'numerical_results/bootstrap_2025.csv');b=b[b.comparison=='Ridge minus DTMC']
fig,axs=plt.subplots(1,3,figsize=(10,3.6))
for ax,metric in zip(axs,['AUROC','Brier','LogLoss']):
    row=b[b.metric==metric].iloc[0];ax.errorbar(row.point,0,xerr=np.array([[row.point-row.lower],[row.upper-row.point]]),fmt='o',capsize=5,color='#155d8b');ax.axvline(0,color='#777',ls=':');ax.set(yticks=[],xlabel='Ridge minus DTMC',title=metric,ylim=(-1,1));ax.text(.5,.83,f'{row.point:.4f}\n[{row.lower:.4f}, {row.upper:.4f}]',transform=ax.transAxes,ha='center')
fig.suptitle('2025 paired differences: descriptive 95% block-bootstrap intervals');fig.tight_layout();write(fig,'2025_paired_differences')

# Representação do índice, estados e dinâmica mensal.
panel=pd.read_csv(ROOT.parent/'03_analytical_dataset/regional_monthly_reference.csv',parse_dates=['period'])
fig,ax=plt.subplots(figsize=(11,4.5))
for region,g in panel.groupby('region'):
    ax.plot(g.period,g.PI_ref,label=region.replace('Região de Saúde ','').replace('do ',''),lw=1)
ax.set(xlabel='Month',ylabel='Pressure index',title='Regional operational pressure, 2017–2025')
ax.legend(fontsize=8,ncol=3);write(fig,'pressure_index_by_region')
states=panel.pivot(index='region',columns='period',values='S_ref').sort_index()
fig,ax=plt.subplots(figsize=(12,3.8))
im=ax.imshow(states,aspect='auto',vmin=1,vmax=5,cmap='YlOrRd',interpolation='nearest')
ax.set_yticks(range(len(states)),[r.replace('Região de Saúde ','') for r in states.index],fontsize=8)
positions=[i for i,date in enumerate(states.columns) if date.month==1]
ax.set_xticks(positions,[states.columns[i].year for i in positions]);ax.set(title='Monthly regional pressure states',xlabel='Year')
fig.colorbar(im,ax=ax,ticks=[1,2,3,4,5],label='Ordinal state');write(fig,'regional_ordinal_states')
trans=pd.read_csv(ROOT/'numerical_results/transition_probabilities.csv')
values=trans.select_dtypes(include=[np.number]).to_numpy()
if values.shape[1]>5:values=values[:,-5:]
fig,ax=plt.subplots(figsize=(5.5,4.8));im=ax.imshow(values,cmap='Blues',vmin=0,vmax=1)
for i in range(5):
    for j in range(5):ax.text(j,i,f'{values[i,j]:.2f}',ha='center',va='center',color='white' if values[i,j]>.5 else 'black')
ax.set(xticks=range(5),yticks=range(5),xticklabels=range(1,6),yticklabels=range(1,6),xlabel='Next state',ylabel='Current state',title='Monthly DTMC transition probabilities')
fig.colorbar(im,ax=ax);write(fig,'dtmc_transition_matrix')
