"""Executa o pipeline e valida as previsões calculadas nesta execução."""
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parent
for folder in ['04_analysis','05_model_development','06_final_evaluation_2025','07_secondary_evaluations','08_results','09_validation']:
    (ROOT/folder).mkdir(exist_ok=True)
cache=ROOT/'08_results/cache';cache.mkdir(exist_ok=True)
os.environ.setdefault('MPLCONFIGDIR',str(cache/'matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME',str(cache))
for name in ['00_preprocess_sources.py','01_prepare_analytical_dataset.py','02_reproduce_primary_c10.py','03_secondary_evaluations.py','04_make_figures.py','05_export_results.py']:
    subprocess.run([sys.executable,str(ROOT/'scripts'/name)],cwd=ROOT,check=True)
subprocess.run([sys.executable,'-m','unittest','discover','-s','09_validation','-p','test_*.py','-v'],cwd=ROOT,check=True)
print('Pipeline concluído e previsões de 2025 validadas.')
