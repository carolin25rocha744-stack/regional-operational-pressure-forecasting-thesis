# Entrega final da dissertação

Dados, scripts e resultados numa única versão de trabalho, organizados pela sequência do estudo.

| Pasta | Conteúdo |
|---|---|
| `00_documentation` | Dicionário, instruções de execução e correspondência entre scripts e dissertação |
| `01_data_raw` | 30 ficheiros originais do SNS: seis fontes por região |
| `02_data_intermediate` | Indicadores limpos, harmonizados e agregados, reconstruídos a partir das fontes SNS |
| `03_analytical_dataset` | Painel analítico, índice, estados, alvo e preditores |
| `04_analysis` | Robustez do índice, episódios, matrizes de transição e horizontes DTMC |
| `05_model_development` | Previsões e métricas da validação temporal 2021–2024 |
| `06_final_evaluation_2025` | Previsões mensais ridge–DTMC e métricas de 2025 |
| `07_secondary_evaluations` | Novos episódios, alertas, bootstrap, calibração e avaliação geográfica |
| `08_results` | Figuras e resultados numéricos |
| `09_validation` | Testes, hashes das entradas e relatórios de equivalência |
| `scripts` | Scripts executáveis e funções de suporte |

## Executar

Python 3.13.5. Na pasta descompactada:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python run_all.py
```

Em Windows, ativa o ambiente com `.venv\\Scripts\\activate`.

O pipeline lê os 30 ficheiros de `01_data_raw`, reconstrói os indicadores mensais em `02_data_intermediate`, gera o painel analítico a partir desses indicadores e compara-o com o livro analítico preservado apenas como referência de auditoria. Depois reproduz as análises, as previsões e as figuras e executa os testes.

`03_analytical_dataset/processed_inputs/dataset(3).xlsx` é mantido para verificar a equivalência do índice e dos estados de referência; já não é a fonte usada para alimentar a modelação. Os dados contextuais e de horas suplementares continuam a ser entradas mensais processadas: a extração original dessas duas fontes não é reconstruída neste pacote.

A seleção histórica completa de hiperparâmetros não é reexecutada; a especificação principal é ridge com `C=10`. As figuras incluídas são geradas pelos scripts deste pacote, mas não representam a reconstrução de todas as ilustrações da dissertação.

Ver [instruções de execução](00_documentation/EXECUCAO.md), [dicionário de dados](00_documentation/DICIONARIO_DADOS.md) e [mapa dos scripts](00_documentation/MAPA_SCRIPTS_DISSERTACAO.md).
